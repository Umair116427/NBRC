// ============================================================
//  Nabirosa Closet – Main Script
//  Handles: Loader, Navbar, Mobile Menu, GSAP, Cart, Checkout
// ============================================================

// Register GSAP ScrollTrigger only if it exists (not available on non-home pages)
if (typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
}

// ── Cart State ──────────────────────────────────────────────
let cart = JSON.parse(localStorage.getItem('nc_cart')) || [];

function saveCart() {
    localStorage.setItem('nc_cart', JSON.stringify(cart));
}

function getCartTotalQty() {
    return cart.reduce((sum, i) => sum + i.qty, 0);
}

function getSubtotal() {
    return cart.reduce((sum, i) => sum + i.price * i.qty, 0);
}

function updateCartBadge() {
    document.querySelectorAll('.cart-count, .mobile-cart-count, .bottom-nav-cart-badge').forEach(el => {
        el.textContent = getCartTotalQty();
        el.style.display = getCartTotalQty() === 0 ? 'none' : 'flex';
    });
}

// ── Add to Cart ─────────────────────────────────────────────
function addToCart(product) {
    const existing = cart.find(i => i.id === product.id);
    if (existing) {
        existing.qty += 1;
    } else {
        cart.push({ ...product, qty: 1 });
    }
    saveCart();
    updateCartBadge();
    showAddedFeedback();
}

function showAddedFeedback() {
    // small toast
    let toast = document.getElementById('nc-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'nc-toast';
        toast.className = 'nc-toast';
        document.body.appendChild(toast);
    }
    toast.innerHTML = '<i class="fas fa-check-circle"></i> Added to bag!';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

// ── DOMContentLoaded ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

    updateCartBadge();

    // ── Mobile Menu Toggle ───────────────────────────────
    const hamburger = document.querySelector('.hamburger');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileOverlay = document.getElementById('mobileOverlay');
    const closeMenu = document.querySelector('.close-menu');

    function openMobileMenu() {
        mobileMenu && mobileMenu.classList.add('active');
        mobileOverlay && mobileOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closeMobileMenu() {
        mobileMenu && mobileMenu.classList.remove('active');
        mobileOverlay && mobileOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (hamburger) hamburger.addEventListener('click', openMobileMenu);
    if (closeMenu) closeMenu.addEventListener('click', closeMobileMenu);
    if (mobileOverlay) mobileOverlay.addEventListener('click', closeMobileMenu);
    document.querySelectorAll('.mobile-menu a').forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    // ── Search Overlay ───────────────────────────────────
    const searchOverlay = document.getElementById('searchOverlay');
    const searchClose = document.getElementById('searchClose');
    const searchInput = document.getElementById('searchInput');
    const searchIcon = document.querySelector('.nav-icons .fa-search');

    if (searchIcon && searchOverlay) {
        searchIcon.addEventListener('click', () => {
            searchOverlay.classList.add('active');
            setTimeout(() => searchInput && searchInput.focus(), 100);
        });
    }
    if (searchClose) {
        searchClose.addEventListener('click', () => searchOverlay.classList.remove('active'));
    }
    if (searchOverlay) {
        searchOverlay.addEventListener('click', (e) => {
            if (e.target === searchOverlay) searchOverlay.classList.remove('active');
        });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchOverlay) searchOverlay.classList.remove('active');
    });

    // ── Navbar Scroll Effect ─────────────────────────────
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 40) {
                navbar.classList.add('scrolled');
                navbar.style.boxShadow = '0 8px 30px rgba(0,0,0,0.10)';
                navbar.style.padding = '0 5%';
            } else {
                navbar.classList.remove('scrolled');
                navbar.style.boxShadow = '';
                navbar.style.padding = '';
            }
        });
    }

    // ── Smooth Scroll ────────────────────────────────────
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // ── Loading Screen (index.html only) ────────────────
    const loader = document.querySelector('.loader');
    if (loader) {
        const tl = gsap.timeline();
        tl.to('.loader-text', { opacity: 1, duration: 1, y: -20, ease: 'power2.out' })
            .to('.loader-bar', { width: '200px', duration: 2, ease: 'power1.inOut' }, '-=0.5')
            .to('.loader', { y: '-100%', duration: 1, ease: 'power4.inOut', delay: 0.5 })
            .from('.navbar', { y: -100, opacity: 0, duration: 0.8, ease: 'power2.out' })
            .to('.hero-content', { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }, '-=0.4');

        if (typeof ScrollTrigger !== 'undefined') {
            gsap.from('.product-card', {
                scrollTrigger: {
                    trigger: '.featured',
                    start: 'top 80%',
                    toggleActions: 'play none none reverse'
                },
                y: 50, opacity: 0, duration: 1, ease: 'power2.out'
            });
        }
    }

    // ── Shop / New Arrivals card animation ───────────────
    const shopCards = document.querySelectorAll('.shop-card');
    if (shopCards.length) {
        gsap.from(shopCards, {
            y: 40, opacity: 0, duration: 0.7, stagger: 0.15, ease: 'power2.out', delay: 0.2
        });
    }

    // ── Quick View Modal Logic ───────────────────────────
    const qvOverlay = document.getElementById('quickViewOverlay');
    const qvClose = document.getElementById('quickViewClose');
    const qvAddBtn = document.getElementById('qvAddBtn');

    // Quantity controls
    const qvMinus = document.getElementById('qvMinus');
    const qvPlus = document.getElementById('qvPlus');
    const qvQtyInput = document.getElementById('qvQty');

    let currentQvProduct = null;

    if (qvMinus && qvPlus && qvQtyInput) {
        qvMinus.addEventListener('click', () => {
            let val = parseInt(qvQtyInput.value);
            if (val > 1) qvQtyInput.value = val - 1;
        });
        qvPlus.addEventListener('click', () => {
            let val = parseInt(qvQtyInput.value);
            qvQtyInput.value = val + 1;
        });
    }

    function closeQuickView() {
        if (qvOverlay) qvOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (qvClose) qvClose.addEventListener('click', closeQuickView);
    if (qvOverlay) qvOverlay.addEventListener('click', (e) => {
        if (e.target === qvOverlay) closeQuickView();
    });

    document.querySelectorAll('.quick-view-trigger').forEach(card => {
        card.addEventListener('click', (e) => {
            // If they clicked the add to cart button directly, don't open modal
            if (e.target.closest('.add-to-cart-btn') || e.target.closest('.shop-add-btn')) return;

            // Extract data from card
            const imgEl = card.querySelector('img');
            const titleEl = card.querySelector('h3');
            const descEl = card.querySelector('.product-desc') || card.querySelector('p');
            const salePriceEl = card.querySelector('.sale-price') || card.querySelector('.sale');
            const origPriceEl = card.querySelector('.original-price') || card.querySelector('.orig');
            const badgeEl = card.querySelector('.sale-badge') || card.querySelector('.shop-card-badge');
            const pillEl = card.querySelector('.discount-pill') || card.querySelector('.pill');
            const metaContainer = card.querySelector('.product-meta');

            // Check if it's the "Coming Soon" card
            const isComingSoon = card.querySelector('.add-to-cart-btn')?.disabled;

            // Populate Modal
            document.getElementById('qvImage').src = imgEl.src;
            document.getElementById('qvTitle').textContent = titleEl.textContent;

            const qvDesc = document.getElementById('qvDesc');
            if (descEl) qvDesc.textContent = descEl.textContent;
            else qvDesc.textContent = "A stunning piece from Nabirosa Closet.";

            const qvSalePrice = document.getElementById('qvSalePrice');
            const qvOrigPrice = document.getElementById('qvOrigPrice');
            const qvDiscount = document.getElementById('qvDiscount');
            const qvBadge = document.getElementById('qvBadge');
            const qvMeta = document.getElementById('qvMeta');

            if (salePriceEl) qvSalePrice.textContent = salePriceEl.textContent;
            else qvSalePrice.textContent = '';

            if (origPriceEl) {
                qvOrigPrice.textContent = origPriceEl.textContent;
                qvOrigPrice.style.display = 'inline';
            } else {
                qvOrigPrice.style.display = 'none';
            }

            if (pillEl) {
                qvDiscount.textContent = pillEl.textContent;
                qvDiscount.style.display = 'inline-block';
            } else {
                qvDiscount.style.display = 'none';
            }

            if (badgeEl) {
                qvBadge.textContent = badgeEl.textContent;
                qvBadge.style.background = badgeEl.style.background || 'var(--champagne-gold)';
                qvBadge.style.color = badgeEl.style.color || '#fff';
                qvBadge.style.display = 'block';
            } else {
                qvBadge.style.display = 'none';
            }

            if (metaContainer) {
                qvMeta.innerHTML = metaContainer.innerHTML;
                qvMeta.style.display = 'flex';
            } else {
                qvMeta.style.display = 'none';
            }

            // Reset Qty
            if (qvQtyInput) qvQtyInput.value = 1;

            // Handle Coming Soon State
            if (isComingSoon) {
                qvAddBtn.disabled = true;
                qvAddBtn.style.background = '#ccc';
                qvAddBtn.style.color = '#666';
                qvAddBtn.style.cursor = 'not-allowed';
                qvAddBtn.innerHTML = '<i class="fas fa-lock"></i> Stay Tuned';
                if (qvQtyInput) qvQtyInput.disabled = true;
            } else {
                qvAddBtn.disabled = false;
                qvAddBtn.style.background = 'var(--midnight-navy)';
                qvAddBtn.style.color = '#fff';
                qvAddBtn.style.cursor = 'pointer';
                qvAddBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> Add to Bag';
                if (qvQtyInput) qvQtyInput.disabled = false;

                // Store current product for Add to Cart
                currentQvProduct = {
                    id: titleEl.textContent.toLowerCase().replace(/\s+/g, '-'),
                    name: titleEl.textContent,
                    price: salePriceEl ? parseInt(salePriceEl.textContent.replace(/[^0-9]/g, '')) : 0,
                    image: imgEl.src
                };
            }

            // Show Modal
            qvOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    if (qvAddBtn) {
        qvAddBtn.addEventListener('click', () => {
            if (!currentQvProduct || qvAddBtn.disabled) return;

            const qty = parseInt(qvQtyInput.value) || 1;

            // Add quantity times
            for (let i = 0; i < qty; i++) {
                addToCart(currentQvProduct);
            }

            // visually only show feedback once
            qvAddBtn.textContent = '✓ Added!';
            qvAddBtn.style.backgroundColor = 'var(--champagne-gold)';
            qvAddBtn.style.color = 'var(--midnight-navy)';
            setTimeout(() => {
                qvAddBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> Add to Bag';
                qvAddBtn.style.backgroundColor = 'var(--midnight-navy)';
                qvAddBtn.style.color = '#fff';
            }, 1000);
        });
    }

    // ── Add to Cart Button (index / shop pages) ──────────
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            addToCart({
                id: 'handmade-kurti-001',
                name: 'Handmade Embroidered Kurti',
                price: 3200,
                image: 'assets/images/placeholder1.jpg'
            });
            // animate button
            btn.textContent = '✓ Added!';
            btn.style.backgroundColor = 'var(--champagne-gold)';
            btn.style.color = 'var(--midnight-navy)';
            setTimeout(() => {
                btn.textContent = 'Add to Bag';
                btn.style.backgroundColor = '';
                btn.style.color = '';
            }, 1500);
        });
    });

    // ── Cart Page Logic ──────────────────────────────────
    const cartContainer = document.getElementById('cart-items-container');
    if (cartContainer) {
        renderCart();
    }

    // ── Checkout Page Logic ──────────────────────────────
    const checkoutLayout = document.getElementById('checkout-form-layout');
    if (checkoutLayout) {
        initCheckout();
    }

    // ── Policy Popup Logic ───────────────────────────────
    const policyOverlay = document.getElementById('policyOverlay');
    const policyClose = document.getElementById('policyClose');

    function openPolicy(section) {
        if (!policyOverlay) return;
        // Hide all sections
        policyOverlay.querySelectorAll('.policy-section').forEach(sec => sec.style.display = 'none');
        // Show the requested section
        const target = document.getElementById('policy-' + section);
        if (target) target.style.display = 'block';
        // Scroll modal to top
        const inner = policyOverlay.querySelector('.policy-modal');
        if (inner) inner.scrollTop = 0;
        policyOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closePolicy() {
        if (!policyOverlay) return;
        policyOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.policy-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            openPolicy(link.dataset.section);
        });
    });

    if (policyClose) policyClose.addEventListener('click', closePolicy);
    if (policyOverlay) {
        policyOverlay.addEventListener('click', (e) => {
            if (e.target === policyOverlay) closePolicy();
        });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && policyOverlay && policyOverlay.classList.contains('active')) closePolicy();
    });
});

// ============================================================
//  CART PAGE
// ============================================================
function renderCart() {
    const container = document.getElementById('cart-items-container');
    const emptyEl = document.getElementById('empty-cart');
    const summaryEl = document.getElementById('cart-summary');
    const cartInner = document.querySelector('.cart-page-inner');

    if (!container) return;

    if (cart.length === 0) {
        container.innerHTML = '';
        emptyEl.style.display = 'flex';
        summaryEl.style.display = 'none';
        if (cartInner) cartInner.classList.add('is-empty');
        return;
    }

    emptyEl.style.display = 'none';
    summaryEl.style.display = 'block';
    if (cartInner) cartInner.classList.remove('is-empty');

    container.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <div class="cart-item-img">
                <img src="${item.image}" alt="${item.name}"
                    onerror="this.src='https://placehold.co/120x140/F3E8EA/243A73?text=Nabirosa'">
            </div>
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p class="cart-item-price">PKR ${item.price.toLocaleString()}</p>
                <div class="qty-controls">
                    <button class="qty-btn" onclick="changeQty('${item.id}', -1)"><i class="fas fa-minus"></i></button>
                    <span class="qty-num">${item.qty}</span>
                    <button class="qty-btn" onclick="changeQty('${item.id}', 1)"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            <div class="cart-item-right">
                <span class="cart-item-total">PKR ${(item.price * item.qty).toLocaleString()}</span>
                <button class="remove-item-btn" onclick="removeItem('${item.id}')"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>
    `).join('');

    updateSummary();

    // Animate items in
    gsap.from('.cart-item', {
        y: 20, opacity: 0, duration: 0.4, stagger: 0.1, ease: 'power2.out'
    });
}

function changeQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
        cart = cart.filter(i => i.id !== id);
    }
    saveCart();
    updateCartBadge();
    renderCart();
}

function removeItem(id) {
    const el = document.querySelector(`.cart-item[data-id="${id}"]`);
    if (el) {
        gsap.to(el, {
            opacity: 0, x: 30, duration: 0.3, ease: 'power2.in', onComplete: () => {
                cart = cart.filter(i => i.id !== id);
                saveCart();
                updateCartBadge();
                renderCart();
            }
        });
    }
}

function updateSummary() {
    const subtotal = getSubtotal();
    const shipping = subtotal > 0 ? 200 : 0;
    const total = subtotal + shipping;

    const fmt = n => `PKR ${n.toLocaleString()}`;

    const el = (id) => document.getElementById(id);
    if (el('cart-subtotal')) el('cart-subtotal').textContent = fmt(subtotal);
    if (el('cart-shipping')) el('cart-shipping').textContent = fmt(shipping);
    if (el('cart-total')) el('cart-total').textContent = fmt(total);
}

// ============================================================
//  CHECKOUT PAGE
// ============================================================
function initCheckout() {
    // Show items preview in sidebar
    renderCheckoutSidebar();

    // Step navigation
    document.getElementById('go-to-step-2')?.addEventListener('click', () => {
        if (validateDelivery()) goToStep(2);
    });
    document.getElementById('back-to-step-1')?.addEventListener('click', () => goToStep(1));
    document.getElementById('go-to-step-3')?.addEventListener('click', () => {
        buildReview();
        goToStep(3);
    });
    document.getElementById('back-to-step-2')?.addEventListener('click', () => goToStep(2));
    document.getElementById('place-order-btn')?.addEventListener('click', placeOrder);


}

function renderCheckoutSidebar() {
    const preview = document.getElementById('checkout-items-preview');
    const coSubtotal = document.getElementById('co-subtotal');
    const coTotal = document.getElementById('co-total');
    if (!preview) return;

    const subtotal = getSubtotal();
    const total = subtotal + 200;

    preview.innerHTML = cart.map(item => `
        <div class="co-item-row">
            <img src="${item.image}" alt="${item.name}"
                onerror="this.src='https://placehold.co/60x70/F3E8EA/243A73?text=N'">
            <div class="co-item-info">
                <span class="co-item-name">${item.name}</span>
                <span class="co-item-qty">× ${item.qty}</span>
            </div>
            <span class="co-item-price">PKR ${(item.price * item.qty).toLocaleString()}</span>
        </div>
    `).join('') || '<p class="empty-bag-note">No items in bag.</p>';

    if (coSubtotal) coSubtotal.textContent = `PKR ${subtotal.toLocaleString()}`;
    if (coTotal) coTotal.textContent = `PKR ${total.toLocaleString()}`;
}

function goToStep(num) {
    [1, 2, 3].forEach(n => {
        const step = document.getElementById(`form-step-${n}`);
        const ind = document.getElementById(`step-indicator-${n}`);
        if (step) step.style.display = n === num ? 'block' : 'none';
        if (ind) {
            ind.classList.toggle('active', n === num);
            ind.classList.toggle('completed', n < num);
        }
    });
    // Animate step in
    const activeStep = document.getElementById(`form-step-${num}`);
    if (activeStep) {
        gsap.from(activeStep, { opacity: 0, y: 20, duration: 0.4, ease: 'power2.out' });
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function validateDelivery() {
    const fields = ['first-name', 'last-name', 'phone', 'address', 'city'];
    let valid = true;
    fields.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        if (!el.value.trim()) {
            el.classList.add('input-error');
            valid = false;
        } else {
            el.classList.remove('input-error');
        }
    });
    if (!valid) {
        // shake form
        const form = document.getElementById('delivery-form');
        gsap.from(form, { x: -8, duration: 0.4, repeat: 3, yoyo: true, ease: 'power1.inOut' });
    }
    return valid;
}

function buildReview() {
    const deliveryEl = document.getElementById('review-delivery');
    const paymentEl = document.getElementById('review-payment');
    const itemsEl = document.getElementById('review-items');
    const totalEl = document.getElementById('review-total');

    const fname = document.getElementById('first-name')?.value || '';
    const lname = document.getElementById('last-name')?.value || '';
    const phone = document.getElementById('phone')?.value || '';
    const address = document.getElementById('address')?.value || '';
    const city = document.getElementById('city')?.value || '';

    if (deliveryEl) {
        deliveryEl.innerHTML = `
            <p>${fname} ${lname}</p>
            <p>${phone}</p>
            <p>${address}, ${city}</p>
        `;
    }

    if (paymentEl) paymentEl.innerHTML = `<p>Cash on Delivery</p>`;

    if (itemsEl) {
        itemsEl.innerHTML = cart.map(item => `
            <div class="review-item-row">
                <span>${item.name} × ${item.qty}</span>
                <span>PKR ${(item.price * item.qty).toLocaleString()}</span>
            </div>
        `).join('');
    }

    if (totalEl) {
        totalEl.textContent = `PKR ${(getSubtotal() + 200).toLocaleString()}`;
    }
}

function placeOrder() {
    const btn = document.getElementById('place-order-btn');
    if (!btn) return;

    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Placing Order...';
    btn.disabled = true;

    setTimeout(() => {
        // Clear cart
        cart = [];
        saveCart();
        updateCartBadge();

        // Show confirmation
        const layout = document.getElementById('checkout-form-layout');
        const confirmed = document.getElementById('order-confirmed');
        const header = document.querySelector('.checkout-header');

        if (layout) layout.style.display = 'none';
        if (header) header.style.display = 'none';
        if (confirmed) {
            confirmed.style.display = 'flex';
            gsap.from(confirmed, { opacity: 0, scale: 0.9, duration: 0.6, ease: 'back.out(1.7)' });
        }
    }, 1500);
}
