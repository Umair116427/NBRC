<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_Database {

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $orders_table = $wpdb->prefix . 'nc_orders';
        $sql_orders = "CREATE TABLE IF NOT EXISTS {$orders_table} (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            order_number VARCHAR(30)  NOT NULL,
            status       VARCHAR(30)  NOT NULL DEFAULT 'pending',
            first_name   VARCHAR(100) NOT NULL DEFAULT '',
            last_name    VARCHAR(100) NOT NULL DEFAULT '',
            phone        VARCHAR(50)  NOT NULL DEFAULT '',
            email        VARCHAR(150)          DEFAULT '',
            address      TEXT         NOT NULL,
            city         VARCHAR(100) NOT NULL DEFAULT '',
            postal       VARCHAR(20)           DEFAULT '',
            notes        TEXT                  DEFAULT '',
            payment      VARCHAR(50)  NOT NULL DEFAULT 'cod',
            subtotal     DECIMAL(10,2) NOT NULL DEFAULT 0,
            shipping     DECIMAL(10,2) NOT NULL DEFAULT 200,
            total        DECIMAL(10,2) NOT NULL DEFAULT 0,
            items_json   LONGTEXT     NOT NULL,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY order_number (order_number),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset};";

        $products_table = $wpdb->prefix . 'nc_products';
        $sql_products = "CREATE TABLE IF NOT EXISTS {$products_table} (
            id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name           VARCHAR(200) NOT NULL,
            slug           VARCHAR(200) NOT NULL,
            description    TEXT                  DEFAULT '',
            price          DECIMAL(10,2) NOT NULL DEFAULT 0,
            orig_price     DECIMAL(10,2)          DEFAULT NULL,
            badge          VARCHAR(50)            DEFAULT '',
            meta_tags      VARCHAR(500)           DEFAULT '',
            image_url      VARCHAR(500)           DEFAULT '',
            image2_url     VARCHAR(500)           DEFAULT '',
            image3_url     VARCHAR(500)           DEFAULT '',
            video_url      VARCHAR(500)           DEFAULT '',
            is_coming_soon TINYINT(1) NOT NULL DEFAULT 0,
            is_new_arrival TINYINT(1) NOT NULL DEFAULT 0,
            sort_order     INT          NOT NULL DEFAULT 0,
            created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql_orders );
        dbDelta( $sql_products );
        update_option( 'nc_db_version', NC_VERSION );
    }
}
