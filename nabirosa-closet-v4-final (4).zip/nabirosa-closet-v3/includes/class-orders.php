<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_Orders {

    public static $statuses = [
        'pending'    => 'Pending',
        'processing' => 'Processing',
        'shipped'    => 'Shipped',
        'delivered'  => 'Delivered',
        'cancelled'  => 'Cancelled',
    ];

    public static function generate_order_number() {
        return 'NC-' . strtoupper( substr( uniqid(), -6 ) ) . '-' . date( 'ymd' );
    }

    public static function create( $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';

        $items   = $data['items'] ?? [];
        $subtotal = array_reduce( $items, fn( $c, $i ) => $c + ( floatval( $i['price'] ) * intval( $i['qty'] ) ), 0 );
        $shipping = 200;
        $total    = $subtotal + $shipping;

        $row = [
            'order_number' => self::generate_order_number(),
            'status'       => 'pending',
            'first_name'   => sanitize_text_field( $data['first_name'] ?? '' ),
            'last_name'    => sanitize_text_field( $data['last_name'] ?? '' ),
            'phone'        => sanitize_text_field( $data['phone'] ?? '' ),
            'email'        => sanitize_email( $data['email'] ?? '' ),
            'address'      => sanitize_textarea_field( $data['address'] ?? '' ),
            'city'         => sanitize_text_field( $data['city'] ?? '' ),
            'postal'       => sanitize_text_field( $data['postal'] ?? '' ),
            'notes'        => sanitize_textarea_field( $data['notes'] ?? '' ),
            'payment'      => sanitize_text_field( $data['payment'] ?? 'cod' ),
            'subtotal'     => $subtotal,
            'shipping'     => $shipping,
            'total'        => $total,
            'items_json'   => wp_json_encode( $items ),
        ];

        $inserted = $wpdb->insert( $table, $row );
        if ( ! $inserted ) return false;

        $order_id = $wpdb->insert_id;
        $order    = self::get( $order_id );

        // Send confirmation email if email provided
        if ( ! empty( $row['email'] ) ) {
            self::send_confirmation_email( $order );
        }

        // Notify admin
        self::notify_admin( $order );

        return $order;
    }

    public static function get( $id ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
        if ( $row ) {
            $row->items = json_decode( $row->items_json, true );
        }
        return $row;
    }

    public static function get_by_number( $order_number ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE order_number = %s", $order_number ) );
        if ( $row ) {
            $row->items = json_decode( $row->items_json, true );
        }
        return $row;
    }

    public static function get_all( $args = [] ) {
        global $wpdb;
        $table   = $wpdb->prefix . 'nc_orders';
        $where   = [];
        $params  = [];

        if ( ! empty( $args['status'] ) ) {
            $where[]  = 'status = %s';
            $params[] = $args['status'];
        }
        if ( ! empty( $args['search'] ) ) {
            $where[]  = '(order_number LIKE %s OR first_name LIKE %s OR last_name LIKE %s OR phone LIKE %s)';
            $like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $params   = array_merge( $params, [ $like, $like, $like, $like ] );
        }

        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $limit     = intval( $args['per_page'] ?? 20 );
        $offset    = intval( $args['offset'] ?? 0 );
        $order_by  = 'ORDER BY created_at DESC';

        $sql = "SELECT * FROM {$table} {$where_sql} {$order_by} LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;

        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
        foreach ( $rows as $row ) {
            $row->items = json_decode( $row->items_json, true );
        }
        return $rows;
    }

    public static function count( $args = [] ) {
        global $wpdb;
        $table  = $wpdb->prefix . 'nc_orders';
        $where  = [];
        $params = [];
        if ( ! empty( $args['status'] ) ) {
            $where[]  = 'status = %s';
            $params[] = $args['status'];
        }
        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $sql = "SELECT COUNT(*) FROM {$table} {$where_sql}";
        return $params ? intval( $wpdb->get_var( $wpdb->prepare( $sql, $params ) ) ) : intval( $wpdb->get_var( $sql ) );
    }

    public static function update_status( $id, $status ) {
        global $wpdb;
        if ( ! array_key_exists( $status, self::$statuses ) ) return false;
        return $wpdb->update( $wpdb->prefix . 'nc_orders', [ 'status' => $status ], [ 'id' => $id ] );
    }

    public static function revenue_stats() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        return [
            'total_orders'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
            'total_revenue'  => (float) $wpdb->get_var( "SELECT COALESCE(SUM(total),0) FROM {$table} WHERE status != 'cancelled'" ),
            'pending'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='pending'" ),
            'processing'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='processing'" ),
            'shipped'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='shipped'" ),
            'delivered'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='delivered'" ),
            'cancelled'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status='cancelled'" ),
        ];
    }

    // ── Emails ───────────────────────────────────────────────
    private static function send_confirmation_email( $order ) {
        if ( ! $order || empty( $order->email ) ) return;
        $subject = 'Order Confirmed — ' . $order->order_number . ' | Nabirosa Closet';
        $message = "Dear {$order->first_name},\n\n";
        $message .= "Thank you for shopping with Nabirosa Closet! 🌸\n\n";
        $message .= "Your order number is: {$order->order_number}\n";
        $message .= "Total: PKR " . number_format( $order->total, 0 ) . "\n";
        $message .= "Payment: " . ucwords( str_replace( '_', ' ', $order->payment ) ) . "\n\n";
        $message .= "We'll contact you shortly to confirm delivery details.\n\n";
        $message .= "Nabirosa Closet Team\n";
        wp_mail( $order->email, $subject, $message, [ 'From: Nabirosa Closet <noreply@' . wp_parse_url( home_url(), PHP_URL_HOST ) . '>' ] );
    }

    private static function notify_admin( $order ) {
        $admin_email = get_option( 'admin_email' );
        $subject     = '🛍️ New Order: ' . $order->order_number;
        $message     = "New order received!\n\n";
        $message    .= "Order: {$order->order_number}\n";
        $message    .= "Customer: {$order->first_name} {$order->last_name}\n";
        $message    .= "Phone: {$order->phone}\n";
        $message    .= "City: {$order->city}\n";
        $message    .= "Total: PKR " . number_format( $order->total, 0 ) . "\n";
        $message    .= "Payment: " . ucwords( $order->payment ) . "\n\n";
        $message    .= "Manage orders: " . admin_url( 'admin.php?page=nabirosa-orders' ) . "\n";
        wp_mail( $admin_email, $subject, $message );
    }
}
