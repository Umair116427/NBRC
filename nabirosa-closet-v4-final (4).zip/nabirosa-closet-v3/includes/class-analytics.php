<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_Analytics {

    // ── Revenue by month (last 8 months) ─────────────────────
    public static function revenue_by_month( $months = 8 ) {
        global $wpdb;
        $table  = $wpdb->prefix . 'nc_orders';
        $labels = [];
        $data   = [];
        $orders_count = [];

        for ( $i = $months - 1; $i >= 0; $i-- ) {
            $ts     = strtotime( "-{$i} months" );
            $year   = date( 'Y', $ts );
            $month  = date( 'm', $ts );
            $labels[] = date( 'M Y', $ts );

            $rev = $wpdb->get_var( $wpdb->prepare(
                "SELECT COALESCE(SUM(total),0) FROM {$table}
                 WHERE YEAR(created_at)=%d AND MONTH(created_at)=%d AND status != 'cancelled'",
                $year, $month
            ));
            $cnt = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table}
                 WHERE YEAR(created_at)=%d AND MONTH(created_at)=%d",
                $year, $month
            ));
            $data[]         = (float) $rev;
            $orders_count[] = (int)   $cnt;
        }

        return [ 'labels' => $labels, 'revenue' => $data, 'orders' => $orders_count ];
    }

    // ── Revenue by day for current month ─────────────────────
    public static function revenue_by_day_this_month() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $days  = (int) date('d'); // days elapsed this month
        $labels = [];
        $data   = [];

        for ( $i = 1; $i <= $days; $i++ ) {
            $labels[] = $i;
            $rev = $wpdb->get_var( $wpdb->prepare(
                "SELECT COALESCE(SUM(total),0) FROM {$table}
                 WHERE YEAR(created_at)=YEAR(NOW()) AND MONTH(created_at)=MONTH(NOW()) AND DAY(created_at)=%d AND status != 'cancelled'",
                $i
            ));
            $data[] = (float) $rev;
        }
        return [ 'labels' => $labels, 'revenue' => $data ];
    }

    // ── Orders by status (for donut) ─────────────────────────
    public static function orders_by_status() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $rows  = $wpdb->get_results(
            "SELECT status, COUNT(*) AS cnt FROM {$table} GROUP BY status"
        );
        $out = [];
        foreach ( NC_Orders::$statuses as $key => $label ) {
            $found = array_filter( $rows, fn($r) => $r->status === $key );
            $found = array_values( $found );
            $out[ $key ] = [ 'label' => $label, 'count' => $found ? (int)$found[0]->cnt : 0 ];
        }
        return $out;
    }

    // ── Top products ─────────────────────────────────────────
    public static function top_products( $limit = 5 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $rows  = $wpdb->get_results( "SELECT items_json, total FROM {$table} WHERE status != 'cancelled'" );

        $products = [];
        foreach ( $rows as $row ) {
            $items = json_decode( $row->items_json, true ) ?: [];
            foreach ( $items as $item ) {
                $name = $item['name'] ?? 'Unknown';
                if ( ! isset( $products[ $name ] ) ) {
                    $products[ $name ] = [ 'name' => $name, 'units_sold' => 0, 'revenue' => 0, 'image_url' => $item['image'] ?? '' ];
                }
                $products[ $name ]['units_sold'] += intval( $item['qty'] ?? 1 );
                $products[ $name ]['revenue'] += floatval( $item['price'] ?? 0 ) * intval( $item['qty'] ?? 1 );
            }
        }
        usort( $products, fn($a,$b) => $b['revenue'] <=> $a['revenue'] );
        return array_map( fn($p) => (object)$p, array_slice( $products, 0, $limit ) );
    }

    // ── Orders by city ───────────────────────────────────────
    public static function orders_by_city( $limit = 5 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT city, COUNT(*) AS order_count, COALESCE(SUM(total),0) AS revenue
             FROM {$table} WHERE status != 'cancelled'
             GROUP BY city ORDER BY order_count DESC LIMIT %d",
            $limit
        ));
    }

    // ── Orders by payment method ─────────────────────────────
    public static function orders_by_payment() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        return $wpdb->get_results(
            "SELECT payment, COUNT(*) AS cnt, COALESCE(SUM(total),0) AS revenue
             FROM {$table} GROUP BY payment ORDER BY cnt DESC"
        );
    }

    // ── KPIs: this month vs last month ───────────────────────
    public static function monthly_kpis() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';

        $this_m_rev = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total),0) FROM {$table}
             WHERE YEAR(created_at)=YEAR(NOW()) AND MONTH(created_at)=MONTH(NOW()) AND status != 'cancelled'"
        );
        $last_m_rev = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total),0) FROM {$table}
             WHERE YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL 1 MONTH))
               AND MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL 1 MONTH))
               AND status != 'cancelled'"
        );
        $this_m_orders = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE YEAR(created_at)=YEAR(NOW()) AND MONTH(created_at)=MONTH(NOW())"
        );
        $last_m_orders = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE YEAR(created_at)=YEAR(DATE_SUB(NOW(),INTERVAL 1 MONTH))
               AND MONTH(created_at)=MONTH(DATE_SUB(NOW(),INTERVAL 1 MONTH))"
        );

        $rev_change    = $last_m_rev    > 0 ? round( ($this_m_rev    - $last_m_rev)    / $last_m_rev    * 100, 1 ) : 0;
        $orders_change = $last_m_orders > 0 ? round( ($this_m_orders - $last_m_orders) / $last_m_orders * 100, 1 ) : 0;

        // avg order value
        $aov = $this_m_orders > 0 ? $this_m_rev / $this_m_orders : 0;
        $last_aov = $last_m_orders > 0 ? $last_m_rev / $last_m_orders : 0;
        $aov_change = $last_aov > 0 ? round( ($aov - $last_aov) / $last_aov * 100, 1 ) : 0;

        // today
        $today_rev = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total),0) FROM {$table} WHERE DATE(created_at)=CURDATE() AND status != 'cancelled'"
        );
        $yesterday_rev = (float) $wpdb->get_var(
            "SELECT COALESCE(SUM(total),0) FROM {$table} WHERE DATE(created_at)=DATE_SUB(CURDATE(),INTERVAL 1 DAY) AND status != 'cancelled'"
        );
        $today_change = $yesterday_rev > 0 ? round( ($today_rev - $yesterday_rev) / $yesterday_rev * 100, 1 ) : 0;

        return [
            'this_m_rev'     => (float) $this_m_rev,
            'last_m_rev'     => (float) $last_m_rev,
            'rev_change'     => (float) $rev_change,
            'this_m_orders'  => (int)   $this_m_orders,
            'last_m_orders'  => (int)   $last_m_orders,
            'orders_change'  => (float) $orders_change,
            'aov'            => (float) $aov,
            'aov_change'     => (float) $aov_change,
            'today_rev'      => (float) $today_rev,
            'yesterday_rev'  => (float) $yesterday_rev,
            'today_change'   => (float) $today_change,
        ];
    }

    // ── Recent activity (last 5 orders) ─────────────────────
    public static function recent_orders( $limit = 6 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_orders';
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d", $limit
        ));
        foreach ( $rows as $r ) $r->items = json_decode( $r->items_json, true );
        return $rows;
    }

    // ── Conversion rate (orders / product views — approx) ────
    public static function conversion_rate() {
        // Approximate: delivered / total * 100
        global $wpdb;
        $table   = $wpdb->prefix . 'nc_orders';
        $total   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $success = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status IN ('delivered','shipped')" );
        return $total > 0 ? round( $success / $total * 100, 1 ) : 0;
    }
}
