<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_Products {

    public static function get_all( $new_arrivals_only = false ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_products';
        if ( $new_arrivals_only ) {
            return $wpdb->get_results( "SELECT * FROM {$table} WHERE is_new_arrival=1 ORDER BY sort_order ASC, id ASC" );
        }
        return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY sort_order ASC, id ASC" );
    }

    public static function get_by_id( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}nc_products WHERE id=%d", $id ) );
    }

    public static function seed_default_products() {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_products';
        if ( $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) > 0 ) return;
        $ph = 'https://placehold.co/600x800/F3E8EA/243A73?text=Nabirosa+Closet';
        $products = [
            [ 'name'=>'Handmade Embroidered Kurti','slug'=>'handmade-embroidered-kurti','description'=>'Exquisite hand-embroidery on premium fabric.','price'=>3200,'orig_price'=>4500,'badge'=>'On Sale','meta_tags'=>'Hand Embroidered,Premium Fabric','image_url'=>$ph,'image2_url'=>'','image3_url'=>'','video_url'=>'','is_coming_soon'=>0,'is_new_arrival'=>1,'sort_order'=>1 ],
            [ 'name'=>'Royal Velvet Suit','slug'=>'royal-velvet-suit','description'=>'Luxurious velvet with intricate detailing.','price'=>5400,'orig_price'=>6500,'badge'=>'New','meta_tags'=>'Royal Velvet,Classic Fit','image_url'=>$ph,'image2_url'=>'','image3_url'=>'','video_url'=>'','is_coming_soon'=>0,'is_new_arrival'=>1,'sort_order'=>2 ],
            [ 'name'=>'Pastel Silk Anarkali','slug'=>'pastel-silk-anarkali','description'=>'Flowy silk anarkali in soft pastel shade.','price'=>8900,'orig_price'=>null,'badge'=>'','meta_tags'=>'Pure Silk,Pastel Tones','image_url'=>$ph,'image2_url'=>'','image3_url'=>'','video_url'=>'','is_coming_soon'=>0,'is_new_arrival'=>1,'sort_order'=>3 ],
            [ 'name'=>'Coming Soon','slug'=>'coming-soon-preview','description'=>'Something magical is being crafted.','price'=>0,'orig_price'=>null,'badge'=>'Preview','meta_tags'=>'','image_url'=>'https://placehold.co/600x800/F3E8EA/243A73?text=Coming+Soon','image2_url'=>'','image3_url'=>'','video_url'=>'','is_coming_soon'=>1,'is_new_arrival'=>0,'sort_order'=>4 ],
        ];
        foreach ( $products as $p ) $wpdb->insert( $table, $p );
    }

    public static function save( $data, $id = null ) {
        global $wpdb;
        $table = $wpdb->prefix . 'nc_products';
        $fields = [
            'name'          => sanitize_text_field( $data['name'] ?? '' ),
            'slug'          => sanitize_title( $data['slug'] ?? $data['name'] ?? '' ),
            'description'   => sanitize_textarea_field( $data['description'] ?? '' ),
            'price'         => floatval( $data['price'] ?? 0 ),
            'orig_price'    => isset($data['orig_price']) && $data['orig_price'] !== '' ? floatval($data['orig_price']) : null,
            'badge'         => sanitize_text_field( $data['badge'] ?? '' ),
            'meta_tags'     => sanitize_text_field( $data['meta_tags'] ?? '' ),
            'image_url'     => esc_url_raw( $data['image_url']  ?? '' ),
            'image2_url'    => esc_url_raw( $data['image2_url'] ?? '' ),
            'image3_url'    => esc_url_raw( $data['image3_url'] ?? '' ),
            'video_url'     => esc_url_raw( $data['video_url']  ?? '' ),
            'is_coming_soon'=> intval( $data['is_coming_soon'] ?? 0 ),
            'is_new_arrival'=> intval( $data['is_new_arrival'] ?? 0 ),
            'sort_order'    => intval( $data['sort_order'] ?? 0 ),
        ];
        if ( $id ) { $wpdb->update( $table, $fields, ['id'=>$id] ); return $id; }
        $wpdb->insert( $table, $fields );
        return $wpdb->insert_id;
    }

    public static function delete( $id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'nc_products', ['id'=>$id] );
    }
}
