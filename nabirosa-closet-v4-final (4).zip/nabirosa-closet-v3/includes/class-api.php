<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_API {

    const NAMESPACE = 'nabirosa/v1';

    public static function register_routes() {
        // Place an order
        register_rest_route( self::NAMESPACE, '/orders', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'create_order' ],
            'permission_callback' => '__return_true',
        ] );

        // Get products (for dynamic product loading)
        register_rest_route( self::NAMESPACE, '/products', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_products' ],
            'permission_callback' => '__return_true',
        ] );

        // Track order by number (customer-facing)
        register_rest_route( self::NAMESPACE, '/orders/(?P<order_number>[A-Z0-9-]+)', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_order' ],
            'permission_callback' => '__return_true',
        ] );
    }

    // ── POST /nabirosa/v1/orders ──────────────────────────────
    public static function create_order( WP_REST_Request $request ) {
        $body = $request->get_json_params();
        if ( empty( $body ) ) {
            $body = $request->get_body_params();
        }

        // Basic validation
        $required = [ 'first_name', 'last_name', 'phone', 'address', 'city' ];
        foreach ( $required as $field ) {
            if ( empty( $body[ $field ] ) ) {
                return new WP_REST_Response( [
                    'success' => false,
                    'message' => ucwords( str_replace( '_', ' ', $field ) ) . ' is required.',
                ], 400 );
            }
        }

        if ( empty( $body['items'] ) || ! is_array( $body['items'] ) ) {
            return new WP_REST_Response( [
                'success' => false,
                'message' => 'No items in cart.',
            ], 400 );
        }

        $order = NC_Orders::create( $body );

        if ( ! $order ) {
            return new WP_REST_Response( [
                'success' => false,
                'message' => 'Could not create order. Please try again.',
            ], 500 );
        }

        return new WP_REST_Response( [
            'success'      => true,
            'order_number' => $order->order_number,
            'total'        => $order->total,
            'message'      => 'Order placed successfully!',
        ], 201 );
    }

    // ── GET /nabirosa/v1/products ────────────────────────────
    public static function get_products( WP_REST_Request $request ) {
        $new_only = $request->get_param( 'new_arrivals' ) === '1';
        $products = NC_Products::get_all( $new_only );

        $out = array_map( function( $p ) {
            $discount = '';
            if ( $p->orig_price && $p->price < $p->orig_price ) {
                $discount = round( ( 1 - $p->price / $p->orig_price ) * 100 ) . '% OFF';
            }
            return [
                'id'            => $p->id,
                'name'          => $p->name,
                'slug'          => $p->slug,
                'description'   => $p->description,
                'price'         => (float) $p->price,
                'orig_price'    => $p->orig_price ? (float) $p->orig_price : null,
                'discount'      => $discount,
                'badge'         => $p->badge,
                'meta_tags'     => array_filter( explode( ',', $p->meta_tags ) ),
                'image_url'     => $p->image_url,
                'is_coming_soon'=> (bool) $p->is_coming_soon,
                'is_new_arrival'=> (bool) $p->is_new_arrival,
            ];
        }, $products );

        return new WP_REST_Response( [ 'success' => true, 'products' => $out ], 200 );
    }

    // ── GET /nabirosa/v1/orders/{order_number} ────────────────
    public static function get_order( WP_REST_Request $request ) {
        $order_number = sanitize_text_field( $request->get_param( 'order_number' ) );
        $order        = NC_Orders::get_by_number( $order_number );

        if ( ! $order ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Order not found.' ], 404 );
        }

        return new WP_REST_Response( [
            'success'      => true,
            'order_number' => $order->order_number,
            'status'       => $order->status,
            'first_name'   => $order->first_name,
            'last_name'    => $order->last_name,
            'total'        => (float) $order->total,
            'payment'      => $order->payment,
            'items'        => $order->items,
            'created_at'   => $order->created_at,
        ], 200 );
    }
}
