<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NC_Admin {

    public static function add_menu() {
        add_menu_page( 'Nabirosa Closet', 'Nabirosa', 'manage_options', 'nabirosa-dashboard',
            [ __CLASS__, 'page_dashboard' ], 'dashicons-store', 30 );
        add_submenu_page( 'nabirosa-dashboard', 'Dashboard',  'Dashboard',  'manage_options', 'nabirosa-dashboard',  [ __CLASS__, 'page_dashboard' ] );
        add_submenu_page( 'nabirosa-dashboard', 'Analytics',  'Analytics',  'manage_options', 'nabirosa-analytics',  [ __CLASS__, 'page_analytics' ] );
        add_submenu_page( 'nabirosa-dashboard', 'Orders',     'Orders',     'manage_options', 'nabirosa-orders',     [ __CLASS__, 'page_orders' ] );
        add_submenu_page( 'nabirosa-dashboard', 'Products',   'Products',   'manage_options', 'nabirosa-products',   [ __CLASS__, 'page_products' ] );
    }

    public static function enqueue_scripts( $hook ) {
        if ( strpos( $hook, 'nabirosa' ) === false ) return;
        wp_enqueue_style(  'nc-admin',    NC_PLUGIN_URL . 'admin/admin-style.css',  [], NC_VERSION );
        wp_enqueue_script( 'chart-js',    'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', [], null, true );
        wp_enqueue_script( 'nc-admin',    NC_PLUGIN_URL . 'admin/admin-script.js',  [ 'jquery', 'chart-js' ], NC_VERSION, true );
        wp_localize_script( 'nc-admin', 'nc_admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'nc_admin_nonce' ),
        ]);
    }

    public static function page_dashboard() {
        $stats    = NC_Orders::revenue_stats();
        $kpis     = NC_Analytics::monthly_kpis();
        $recent   = NC_Analytics::recent_orders(6);
        $top_prods= NC_Analytics::top_products(5);
        include NC_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    public static function page_analytics() {
        $stats     = NC_Orders::revenue_stats();
        $kpis      = NC_Analytics::monthly_kpis();
        $by_month  = NC_Analytics::revenue_by_month(8);
        $by_day    = NC_Analytics::revenue_by_day_this_month();
        $by_status = NC_Analytics::orders_by_status();
        $by_city   = NC_Analytics::orders_by_city(6);
        $by_payment= NC_Analytics::orders_by_payment();
        $top_products = NC_Analytics::top_products(8);
        $conv_rate = NC_Analytics::conversion_rate();
        include NC_PLUGIN_DIR . 'admin/views/analytics.php';
    }

    public static function page_orders() {
        if ( isset( $_GET['order_id'] ) ) {
            $order = NC_Orders::get( intval( $_GET['order_id'] ) );
            if ( $order ) { include NC_PLUGIN_DIR . 'admin/views/order-detail.php'; return; }
        }
        $status = sanitize_text_field( $_GET['status'] ?? '' );
        $search = sanitize_text_field( $_GET['s'] ?? '' );
        $page   = max( 1, intval( $_GET['paged'] ?? 1 ) );
        $orders = NC_Orders::get_all([ 'status'=>$status,'search'=>$search,'per_page'=>20,'offset'=>($page-1)*20 ]);
        $total  = NC_Orders::count([ 'status'=>$status,'search'=>$search ]);
        $stats  = NC_Orders::revenue_stats();
        include NC_PLUGIN_DIR . 'admin/views/orders-list.php';
    }

    public static function page_products() {
        if ( isset($_POST['nc_product_nonce']) && wp_verify_nonce($_POST['nc_product_nonce'],'nc_save_product') ) {
            NC_Products::save( $_POST, intval($_POST['product_id'] ?? 0) ?: null );
        }
        if ( isset($_GET['delete_product']) && check_admin_referer('nc_delete_product') ) {
            NC_Products::delete( intval($_GET['delete_product']) );
        }
        $stats        = NC_Orders::revenue_stats();
        $edit_product = isset($_GET['edit_product']) ? NC_Products::get_by_id(intval($_GET['edit_product'])) : null;
        $products     = NC_Products::get_all();
        include NC_PLUGIN_DIR . 'admin/views/products.php';
    }

    public static function ajax_update_status() {
        check_ajax_referer('nc_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $result = NC_Orders::update_status( intval($_POST['order_id']??0), sanitize_text_field($_POST['status']??'') );
        wp_send_json([ 'success' => (bool)$result ]);
    }

    public static function ajax_analytics() {
        check_ajax_referer('nc_admin_nonce','nonce');
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $range  = sanitize_text_field($_POST['range'] ?? '8');
        $months = $range === '12' ? 12 : 8;
        $data   = NC_Analytics::revenue_by_month($months);
        wp_send_json_success([
            'labels'  => $data['labels'],
            'revenue' => $data['revenue'],
            'orders'  => $data['orders'],
        ]);
    }
}
