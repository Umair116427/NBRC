<?php if(!defined('ABSPATH'))exit;
// Group orders by date
$orders_by_day = [];
foreach($orders as $o){
  $day = date('Y-m-d', strtotime($o->created_at));
  $orders_by_day[$day][] = $o;
}
function nc_day_label($date_str){
  $ts = strtotime($date_str);
  $today = date('Y-m-d'); $yesterday = date('Y-m-d', strtotime('-1 day'));
  if($date_str===$today)     return 'Today';
  if($date_str===$yesterday) return 'Yesterday';
  return date('l, d F Y', $ts);
}
?>
<div class="wrap nc-admin">

<!-- ── Sidebar ─────────────────────────────────── -->
<nav class="nc-sidebar">
  <div class="nc-sidebar-brand">
    <div class="nc-sidebar-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg></div>
    <div><div class="nc-sidebar-brand-name">Nabirosa Closet</div><div class="nc-sidebar-brand-sub">Admin Panel v4</div></div>
  </div>
  <div class="nc-sidebar-nav">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-dashboard');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>Dashboard</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Analytics</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-nav-item active"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Orders<?php if($stats['pending']>0):?><span class="nc-nav-badge"><?php echo $stats['pending'];?></span><?php endif;?></a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-products');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>Products</a>
  </div>
  <div class="nc-sidebar-footer"><a href="<?php echo home_url('/');?>" target="_blank" class="nc-nav-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>View Store</a></div>
</nav>

<div class="nc-wrap">

<div class="nc-page-header">
  <div>
    <h1 class="nc-page-title">Orders</h1>
    <p class="nc-page-sub"><?php echo $total;?> order<?php echo $total!==1?'s':'';?> total</p>
  </div>
  <div class="nc-page-actions">
    <!-- Export CSV -->
    <div class="nc-export-wrap">
      <button class="nc-btn nc-btn-outline nc-btn-sm nc-export-toggle" type="button">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Export
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="nc-export-dropdown">
        <div class="nc-export-section">Orders</div>
        <button class="nc-export-item" onclick="ncExportOrdersCSV()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          Export as CSV
        </button>
        <button class="nc-export-item" onclick="ncPrintOrdersTable()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print List
        </button>
      </div>
    </div>
  </div>
</div>

<div class="nc-card">

  <!-- Filter bar -->
  <div class="nc-filter-bar">
    <?php
    $tab_list=[
      ''=>['All',$stats['total_orders']],
      'pending'=>['Pending',$stats['pending']],
      'processing'=>['Processing',$stats['processing']],
      'shipped'=>['Shipped',$stats['shipped']],
      'delivered'=>['Delivered',$stats['delivered']],
      'cancelled'=>['Cancelled',$stats['cancelled']],
    ];
    ?>
    <div class="nc-tab-group">
    <?php foreach($tab_list as $k=>[$lbl,$cnt]):
      $active=($status===$k)?' active':'';
      $url=admin_url('admin.php?page=nabirosa-orders&status='.$k);
    ?>
      <a href="<?php echo $url;?>" class="nc-tab<?php echo $active;?>"><?php echo $lbl;?> <span class="nc-tab-count"><?php echo $cnt;?></span></a>
    <?php endforeach;?>
    </div>
    <form method="get" action="" style="display:contents">
      <input type="hidden" name="page" value="nabirosa-orders">
      <?php if($status):?><input type="hidden" name="status" value="<?php echo esc_attr($status);?>"><?php endif;?>
      <div class="nc-search-wrap">
        <div class="nc-search-field">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input class="nc-search-input" type="search" name="s" value="<?php echo esc_attr($search);?>" placeholder="Name, phone, order #…">
        </div>
        <button type="submit" class="nc-btn nc-btn-primary nc-btn-sm">Search</button>
        <?php if($search):?>
        <a href="<?php echo admin_url('admin.php?page=nabirosa-orders&status='.$status);?>" class="nc-btn nc-btn-outline nc-btn-sm">Clear</a>
        <?php endif;?>
      </div>
    </form>
  </div><!-- /.nc-filter-bar -->

  <!-- Table -->
  <?php if(empty($orders)):?>
  <div class="nc-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
    <h3>No orders found</h3>
    <p><?php echo $search?'Try a different search.':'Orders appear here once customers place them.';?></p>
  </div>
  <?php else:?>
  <div style="overflow-x:auto" id="nc-orders-table-wrap">
  <table class="nc-table" id="nc-orders-table">
    <thead>
      <tr>
        <th>Order #</th>
        <th>Customer</th>
        <th>City</th>
        <th>Total</th>
        <th>Payment</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($orders_by_day as $day=>$day_orders):
      $day_total = array_sum(array_column($day_orders,'total'));
      $day_count = count($day_orders);
    ?>
      <!-- Day group header -->
      <tr class="nc-day-header">
        <td colspan="7">
          <div class="nc-day-label">
            <?php echo nc_day_label($day);?>
            <span class="nc-day-meta"><?php echo $day_count;?> order<?php echo $day_count!==1?'s':'';?> · PKR <?php echo number_format($day_total,0);?></span>
          </div>
        </td>
      </tr>
      <?php foreach($day_orders as $o):
        $ini=strtoupper(substr($o->first_name,0,1).substr($o->last_name,0,1));
        $pc=['cod'=>'nc-pay-cod','bank'=>'nc-pay-bank','jazzcash'=>'nc-pay-jazzcash'][$o->payment]??'nc-pay-cod';
        $pl=['cod'=>'COD','bank'=>'Bank Transfer','jazzcash'=>'JazzCash'][$o->payment]??ucwords($o->payment);
      ?>
      <tr data-order-id="<?php echo $o->id;?>">
        <td>
          <div class="nc-order-no"><?php echo esc_html($o->order_number);?></div>
          <div class="nc-order-time"><?php echo date('H:i',strtotime($o->created_at));?></div>
        </td>
        <td>
          <div class="nc-customer-cell">
            <div class="nc-avatar"><?php echo esc_html($ini);?></div>
            <div>
              <div class="nc-cust-name"><?php echo esc_html($o->first_name.' '.$o->last_name);?></div>
              <div class="nc-cust-sub"><?php echo esc_html($o->phone);?></div>
            </div>
          </div>
        </td>
        <td style="font-size:13px;color:var(--text2)"><?php echo esc_html($o->city);?></td>
        <td>
          <span class="nc-amount">PKR <?php echo number_format($o->total,0);?></span>
          <div style="font-size:11px;color:var(--text4);margin-top:1px"><?php echo count($o->items??[]);?> item<?php echo count($o->items??[])!==1?'s':'';?></div>
        </td>
        <td><span class="nc-pill <?php echo $pc;?>"><?php echo $pl;?></span></td>
        <td>
          <div style="display:flex;align-items:center;gap:6px">
            <select class="nc-status-select" data-order-id="<?php echo $o->id;?>">
              <?php foreach(NC_Orders::$statuses as $k=>$lbl):?>
              <option value="<?php echo $k;?>" <?php selected($o->status,$k);?>><?php echo $lbl;?></option>
              <?php endforeach;?>
            </select>
          </div>
        </td>
        <td>
          <a href="<?php echo admin_url('admin.php?page=nabirosa-orders&order_id='.$o->id);?>" class="nc-btn nc-btn-outline nc-btn-xs">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            View
          </a>
        </td>
      </tr>
      <?php endforeach;?>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>

  <!-- Pagination -->
  <?php if($total>20):
    $pages_count=ceil($total/20);?>
  <div class="nc-pagination">
    <span class="nc-pagination-info">Showing <?php echo min($total,($page-1)*20+1);?>–<?php echo min($total,$page*20);?> of <?php echo $total;?></span>
    <?php for($i=1;$i<=$pages_count;$i++):
      $url=admin_url('admin.php?page=nabirosa-orders&status='.$status.'&paged='.$i);
    ?><a href="<?php echo $url;?>" class="nc-page-btn<?php echo $i==$page?' active':'';?>"><?php echo $i;?></a><?php endfor;?>
  </div>
  <?php endif;?>
  <?php endif;?>

</div><!-- /.nc-card -->
</div><!-- /.nc-wrap -->
</div><!-- .wrap -->

<script>
// CSV Export
function ncExportOrdersCSV(){
  var rows=[['Order #','Customer','Phone','City','Total','Payment','Status','Date']];
  document.querySelectorAll('#nc-orders-table tbody tr:not(.nc-day-header)').forEach(function(tr){
    var tds=tr.querySelectorAll('td');
    if(!tds.length)return;
    rows.push([
      (tds[0].querySelector('.nc-order-no')||{textContent:''}).textContent.trim(),
      (tds[1].querySelector('.nc-cust-name')||{textContent:''}).textContent.trim(),
      (tds[1].querySelector('.nc-cust-sub')||{textContent:''}).textContent.trim(),
      tds[2].textContent.trim(),
      (tds[3].querySelector('.nc-amount')||{textContent:''}).textContent.trim(),
      (tds[4].querySelector('.nc-pill')||{textContent:''}).textContent.trim(),
      (tds[5].querySelector('.nc-status-select')?.value||''),
      (tds[0].querySelector('.nc-order-time')||{textContent:''}).textContent.trim()
    ]);
  });
  var csv=rows.map(function(r){return r.map(function(c){return '"'+(c||'').replace(/"/g,'""')+'"';}).join(',');}).join('\n');
  var a=document.createElement('a');
  a.href='data:text/csv;charset=utf-8,\uFEFF'+encodeURIComponent(csv);
  a.download='nabirosa-orders-'+new Date().toISOString().slice(0,10)+'.csv';
  a.click();
  document.querySelector('.nc-export-wrap').classList.remove('open');
}
function ncPrintOrdersTable(){ window.print(); }
</script>
