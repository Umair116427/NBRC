<?php if(!defined('ABSPATH'))exit;
function nc_delta($v){
  $up=$v>=0;
  $icon=sprintf('<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="%s"/></svg>',($up?'18 15 12 9 6 15':'6 9 12 15 18 9'));
  return '<span class="'.($up?'nc-delta-up':'nc-delta-dn').'">'.$icon.' '.abs((float)$v).'%</span>';
}
?>
<div class="wrap nc-admin">

<!-- ── Sidebar ─────────────────────────────────────── -->
<nav class="nc-sidebar">
  <div class="nc-sidebar-brand">
    <div class="nc-sidebar-icon">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
    </div>
    <div>
      <div class="nc-sidebar-brand-name">Nabirosa Closet</div>
      <div class="nc-sidebar-brand-sub">Admin Panel v4</div>
    </div>
  </div>
  <div class="nc-sidebar-nav">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-dashboard');?>" class="nc-nav-item active">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      Dashboard
    </a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-nav-item">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
      Analytics
    </a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-nav-item">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      Orders
      <?php if($stats['pending']>0):?><span class="nc-nav-badge"><?php echo $stats['pending'];?></span><?php endif;?>
    </a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-products');?>" class="nc-nav-item">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
      Products
    </a>
  </div>
  <div class="nc-sidebar-footer">
    <a href="<?php echo home_url('/');?>" target="_blank" class="nc-nav-item">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
      View Store
    </a>
  </div>
</nav>

<div class="nc-wrap">

<!-- Header -->
<div class="nc-page-header">
  <div>
    <h1 class="nc-page-title">Dashboard</h1>
    <p class="nc-page-sub"><?php echo date('l, d F Y');?></p>
  </div>
  <div class="nc-page-actions">
    <?php if($stats['pending']>0):?>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders&status=pending');?>" class="nc-btn nc-btn-outline nc-btn-sm">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <?php echo $stats['pending'];?> Pending
    </a>
    <?php endif;?>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-btn nc-btn-primary nc-btn-sm">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
      Analytics
    </a>
  </div>
</div>

<!-- KPIs -->
<div class="nc-kpi-row">
  <?php $kdata=[
    ['Total Orders','nc-kpi-border-top',$stats['total_orders'],null,'<path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>',null,'admin.php?page=nabirosa-orders'],
    ['This Month Revenue','',  'PKR '.number_format($kpis['this_m_rev'],0), $kpis['rev_change'], '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>',null,null],
    ['Today Revenue','',       'PKR '.number_format($kpis['today_rev'],0),   $kpis['today_change'], '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',null,null],
    ['Avg Order Value','',     'PKR '.number_format($kpis['aov'],0),          $kpis['aov_change'],   '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',null,null],
  ];
  foreach($kdata as[$lbl,$extra,$val,$chg,$svg,$meta,$url]):
    $tag=$url?'a':'div'; $attr=$url?'href="'.admin_url($url).'"':'';
  ?>
  <<?php echo $tag.' '.$attr;?> class="nc-kpi <?php echo $extra;?>">
    <div class="nc-kpi-bg-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><?php echo $svg;?></svg></div>
    <div class="nc-kpi-label"><?php echo $lbl;?></div>
    <div class="nc-kpi-value nc-kpi-value-md"><?php echo $val;?></div>
    <?php if($chg!==null && $chg!==''):?>
    <div class="nc-kpi-meta"><?php echo nc_delta($chg);?> vs last month</div>
    <?php endif;?>
  </<?php echo $tag;?>>
  <?php endforeach;?>
</div>

<!-- Chart + Status -->
<div style="display:grid;grid-template-columns:1fr 240px;gap:16px;margin-bottom:16px">
  <div class="nc-card">
    <div class="nc-card-header">
      <h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Revenue — Last 6 Months</h3>
      <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-btn nc-btn-outline nc-btn-sm">Full report →</a>
    </div>
    <div style="padding:16px 18px"><canvas id="dash-chart" height="100"></canvas></div>
  </div>
  <div class="nc-card">
    <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Order Status</h3></div>
    <div style="padding:14px 18px;display:flex;flex-direction:column;gap:8px">
      <?php
      $rows=[['Pending',$stats['pending'],'#f79009'],['Processing',$stats['processing'],'#2e90fa'],['Shipped',$stats['shipped'],'#7f56d9'],['Delivered',$stats['delivered'],'#12b76a'],['Cancelled',$stats['cancelled'],'#f04438']];
      $tot=max(1,$stats['total_orders']);
      foreach($rows as[$l,$c,$col]):?>
      <div>
        <div class="nc-bar-head"><span class="nc-bar-name"><?php echo $l;?></span><span class="nc-bar-num"><?php echo $c;?></span></div>
        <div class="nc-bar-track"><div class="nc-bar-fill" style="width:<?php echo round($c/$tot*100);?>%;background:<?php echo $col;?>"></div></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- Recent Orders -->
<div class="nc-card">
  <div class="nc-card-header">
    <h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Recent Orders</h3>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-btn nc-btn-outline nc-btn-sm">View all →</a>
  </div>
  <?php if(empty($recent)):?>
  <div class="nc-empty">
    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
    <h3>No orders yet</h3><p>Orders will appear here once customers place them.</p>
  </div>
  <?php else:?>
  <div style="overflow-x:auto">
  <table class="nc-table">
    <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach($recent as $o):
      $ini=strtoupper(substr($o->first_name,0,1).substr($o->last_name,0,1));
      $pc=['cod'=>'nc-pay-cod','bank'=>'nc-pay-bank','jazzcash'=>'nc-pay-jazzcash'][$o->payment]??'nc-pay-cod';
      $pl=['cod'=>'COD','bank'=>'Bank Transfer','jazzcash'=>'JazzCash'][$o->payment]??ucwords($o->payment);
    ?>
    <tr>
      <td><div class="nc-order-no"><?php echo esc_html($o->order_number);?></div><div class="nc-order-time"><?php echo date('d M, H:i',strtotime($o->created_at));?></div></td>
      <td><div class="nc-customer-cell"><div class="nc-avatar"><?php echo esc_html($ini);?></div><div><div class="nc-cust-name"><?php echo esc_html($o->first_name.' '.$o->last_name);?></div><div class="nc-cust-sub"><?php echo esc_html($o->city);?></div></div></div></td>
      <td><span class="nc-amount">PKR <?php echo number_format($o->total,0);?></span></td>
      <td><span class="nc-pill <?php echo $pc;?>"><?php echo $pl;?></span></td>
      <td><span class="nc-pill nc-s-<?php echo esc_attr($o->status);?>"><span class="nc-dot"></span><?php echo esc_html(NC_Orders::$statuses[$o->status]??ucfirst($o->status));?></span></td>
      <td><a href="<?php echo admin_url('admin.php?page=nabirosa-orders&order_id='.$o->id);?>" class="nc-btn nc-btn-outline nc-btn-xs">View</a></td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

</div><!-- /.nc-wrap -->
</div><!-- .wrap -->

<script>
document.addEventListener('DOMContentLoaded',function(){
  if(typeof Chart==='undefined')return;
  var d=<?php echo json_encode(NC_Analytics::revenue_by_month(6));?>;
  Chart.defaults.font.family="'Inter',sans-serif";
  new Chart(document.getElementById('dash-chart'),{
    type:'line',
    data:{labels:d.labels,datasets:[{
      data:d.revenue,
      borderColor:'#1d3461',
      backgroundColor:'rgba(29,52,97,.05)',
      tension:.4,fill:true,
      pointRadius:4,pointBackgroundColor:'#1d3461',
      pointBorderColor:'#fff',pointBorderWidth:2,borderWidth:2
    }]},
    options:{responsive:true,plugins:{legend:{display:false},tooltip:{backgroundColor:'#101828',padding:10,cornerRadius:8,callbacks:{label:function(c){return' PKR '+c.parsed.y.toLocaleString();}}}},
    scales:{x:{grid:{display:false},ticks:{font:{size:11},color:'#98a2b3'}},y:{grid:{color:'rgba(0,0,0,.03)'},ticks:{callback:function(v){return'PKR '+v.toLocaleString();},font:{size:11},color:'#98a2b3',maxTicksLimit:5}}}}
  });
});
</script>
