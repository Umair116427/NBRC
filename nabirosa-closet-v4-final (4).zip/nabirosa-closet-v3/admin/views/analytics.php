<?php if(!defined('ABSPATH'))exit;
$ml=json_encode($by_month['labels']);
$mr=json_encode($by_month['revenue']);
$mo=json_encode($by_month['orders']);
$dl=json_encode($by_day['labels']);
$dr=json_encode($by_day['revenue']);
$slabels=json_encode(array_column($by_status,'label'));
$scounts=json_encode(array_column($by_status,'count'));
$pl=[];$pc=[];$pr=[];
foreach($by_payment as $p){$pl[]=ucwords($p->payment);$pc[]=(int)$p->cnt;$pr[]=(float)$p->revenue;}
function nc_d($v){$up=$v>=0;$ic=sprintf('<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="%s"/></svg>',($up?'18 15 12 9 6 15':'6 9 12 15 18 9'));return '<span class="'.($up?'nc-delta-up':'nc-delta-dn').'">'.$ic.' '.abs((float)$v).'%</span>';}
?>
<div class="wrap nc-admin">

<!-- ── Sidebar ─────────────────────────────────── -->
<nav class="nc-sidebar">
  <div class="nc-sidebar-brand">
    <div class="nc-sidebar-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg></div>
    <div><div class="nc-sidebar-brand-name">Nabirosa Closet</div><div class="nc-sidebar-brand-sub">Admin Panel v4</div></div>
  </div>
  <div class="nc-sidebar-nav">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-dashboard');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>Dashboard</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-nav-item active"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Analytics</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Orders</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-products');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>Products</a>
  </div>
  <div class="nc-sidebar-footer"><a href="<?php echo home_url('/');?>" target="_blank" class="nc-nav-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>View Store</a></div>
</nav>

<div class="nc-wrap">

<div class="nc-page-header">
  <div>
    <h1 class="nc-page-title">Analytics</h1>
    <p class="nc-page-sub">Sales performance · <?php echo date('d F Y');?></p>
  </div>
  <div class="nc-page-actions">
    <!-- Export dropdown -->
    <div class="nc-export-wrap">
      <button class="nc-btn nc-btn-outline nc-btn-sm nc-export-toggle">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        Export
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="nc-export-dropdown">
        <div class="nc-export-section">Revenue Data</div>
        <button class="nc-export-item" onclick="ncExportRevenueCSV()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          Revenue CSV
        </button>
        <button class="nc-export-item" onclick="ncExportTopProductsCSV()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
          Top Products CSV
        </button>
        <div class="nc-export-section" style="border-top:1px solid var(--border)">Reports</div>
        <button class="nc-export-item" onclick="window.print()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print Report
        </button>
      </div>
    </div>
  </div>
</div>

<!-- KPIs -->
<div class="nc-kpi-row">
  <div class="nc-kpi nc-kpi-border-top">
    <div class="nc-kpi-bg-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></div>
    <div class="nc-kpi-label">This Month Revenue</div>
    <div class="nc-kpi-value nc-kpi-value-md">PKR <?php echo number_format($kpis['this_m_rev'],0);?></div>
    <div class="nc-kpi-meta"><?php echo nc_d($kpis['rev_change']);?> vs last month</div>
  </div>
  <div class="nc-kpi">
    <div class="nc-kpi-bg-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg></div>
    <div class="nc-kpi-label">Today's Sales</div>
    <div class="nc-kpi-value nc-kpi-value-md">PKR <?php echo number_format($kpis['today_rev'],0);?></div>
    <div class="nc-kpi-meta"><?php echo nc_d($kpis['today_change']);?> vs yesterday</div>
  </div>
  <div class="nc-kpi">
    <div class="nc-kpi-bg-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
    <div class="nc-kpi-label">Avg Order Value</div>
    <div class="nc-kpi-value nc-kpi-value-md">PKR <?php echo number_format($kpis['aov'],0);?></div>
    <div class="nc-kpi-meta"><?php echo nc_d($kpis['aov_change']);?> vs last month</div>
  </div>
  <div class="nc-kpi">
    <div class="nc-kpi-bg-icon"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>
    <div class="nc-kpi-label">Fulfilment Rate</div>
    <div class="nc-kpi-value"><?php echo NC_Analytics::conversion_rate();?>%</div>
    <div class="nc-kpi-meta">Delivered + Shipped</div>
  </div>
</div>

<!-- Main chart -->
<div class="nc-analytics-grid-2">
  <div class="nc-card">
    <div class="nc-card-header">
      <div>
        <div class="nc-chart-title">Revenue & Orders</div>
        <div class="nc-chart-sub">Monthly breakdown</div>
      </div>
      <div class="nc-chips">
        <button class="nc-chip active" data-range="8">8M</button>
        <button class="nc-chip" data-range="12">12M</button>
        <button class="nc-chip" data-range="today">Daily</button>
      </div>
    </div>
    <div style="padding:16px 18px"><canvas id="main-chart" height="120"></canvas></div>
    <div style="display:flex;gap:16px;padding:4px 18px 14px;font-size:12px;color:var(--text3)">
      <span><span style="display:inline-block;width:10px;height:10px;background:#1d3461;border-radius:2px;margin-right:5px"></span>Revenue (PKR)</span>
      <span><span style="display:inline-block;width:10px;height:10px;background:#c9a227;border-radius:2px;margin-right:5px"></span>Orders</span>
    </div>
  </div>

  <!-- Fulfilment gauge -->
  <div class="nc-card" style="display:flex;flex-direction:column">
    <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Fulfilment Rate</h3></div>
    <div style="padding:16px 18px;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center">
      <canvas id="gauge-chart" width="180" height="100" style="max-width:180px"></canvas>
      <div class="nc-gauge-center">
        <div class="nc-gauge-pct"><?php echo NC_Analytics::conversion_rate();?>%</div>
        <div class="nc-gauge-label">of orders fulfilled</div>
      </div>
    </div>
    <div class="nc-gauge-legend" style="border-top:1px solid var(--border);padding:12px 18px 16px;display:flex;flex-direction:column;gap:7px">
      <?php
      $gs=[['Delivered',$stats['delivered']??0,'#12b76a'],['Shipped',$stats['shipped']??0,'#7f56d9'],['Processing',$stats['processing']??0,'#2e90fa'],['Pending',$stats['pending']??0,'#f79009'],['Cancelled',$stats['cancelled']??0,'#f04438']];
      $tot=max(1,array_sum(array_column($gs,1)));
      foreach($gs as[$lbl,$cnt,$col]):?>
      <div style="display:flex;align-items:center;gap:8px;font-size:12px">
        <span style="width:8px;height:8px;border-radius:50%;background:<?php echo $col;?>;flex-shrink:0"></span>
        <span style="flex:1;color:var(--text2)"><?php echo $lbl;?></span>
        <span style="font-weight:700;color:var(--text1)"><?php echo $cnt;?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- 3-col row -->
<div class="nc-analytics-grid-3">

  <!-- Orders by status donut -->
  <div class="nc-card">
    <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>By Status</h3></div>
    <div style="padding:14px 18px"><canvas id="status-donut" height="140"></canvas></div>
    <div class="nc-donut-legend">
      <?php
      $status_colors=['#12b76a','#2e90fa','#7f56d9','#f79009','#f04438'];
      foreach($by_status as $i=>$s):?>
      <div class="nc-legend-row">
        <span class="nc-legend-dot" style="background:<?php echo $status_colors[$i%5];?>"></span>
        <span class="nc-legend-name"><?php echo esc_html($s['label']);?></span>
        <span class="nc-legend-val"><?php echo $s['count'];?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>

  <!-- Payment methods -->
  <div class="nc-card">
    <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Payment Methods</h3></div>
    <div style="padding:16px 18px">
      <?php
      $pay_colors=['#1d3461','#c9a227','#7f56d9'];
      $max_pay=max(1,max($pc?:[1]));
      foreach(array_keys($pc) as $i):?>
      <div style="margin-bottom:14px">
        <div class="nc-bar-head">
          <span class="nc-bar-name"><?php echo esc_html($pl[$i]);?></span>
          <span class="nc-bar-num"><?php echo $pc[$i];?> · PKR <?php echo number_format($pr[$i],0);?></span>
        </div>
        <div class="nc-bar-track"><div class="nc-bar-fill" style="width:<?php echo round($pc[$i]/$max_pay*100);?>%;background:<?php echo $pay_colors[$i%3];?>"></div></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>

  <!-- Top cities -->
  <div class="nc-card">
    <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Top Cities</h3></div>
    <div style="padding:16px 18px">
      <?php
      $max_city=max(1,isset($by_city[0])?$by_city[0]->order_count:1);
      foreach($by_city as $i=>$c):?>
      <div style="margin-bottom:13px">
        <div class="nc-bar-head">
          <span class="nc-bar-name">
            <span style="display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:4px;font-size:10px;font-weight:700;margin-right:5px;<?php echo $i===0?'background:#fef3c7;color:#92400e':($i===1?'background:#f1f5f9;color:#475569':'background:#fff7ed;color:#9a3412');?>"><?php echo $i+1;?></span>
            <?php echo esc_html($c->city);?>
          </span>
          <span class="nc-bar-num"><?php echo $c->order_count;?> orders</span>
        </div>
        <div class="nc-bar-track"><div class="nc-bar-fill" style="width:<?php echo round($c->order_count/$max_city*100);?>%;background:var(--navy)"></div></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>

<!-- Top products -->
<div class="nc-card">
  <div class="nc-card-header">
    <h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Top Products</h3>
    <button class="nc-btn nc-btn-outline nc-btn-sm" onclick="ncExportTopProductsCSV()">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      Export CSV
    </button>
  </div>
  <?php if(empty($top_products)):?>
  <div class="nc-empty"><h3>No data yet</h3><p>Product analytics will appear once orders come in.</p></div>
  <?php else:?>
  <div style="overflow-x:auto">
  <table class="nc-table" id="nc-products-table">
    <thead><tr><th>#</th><th>Product</th><th>Units Sold</th><th>Revenue</th><th>Share</th></tr></thead>
    <tbody>
    <?php
    $top_rev=max(1,isset($top_products[0])?$top_products[0]->revenue:1);
    $total_rev=array_sum(array_column($top_products,'revenue'));
    foreach($top_products as $i=>$p):
      $share=$total_rev>0?round($p->revenue/$total_rev*100):0;
      $ranks=['nc-r1','nc-r2','nc-r3'];$rc=$ranks[$i]??'nc-rn';
    ?>
    <tr>
      <td><span class="nc-rank <?php echo $rc;?>"><?php echo $i+1;?></span></td>
      <td>
        <div style="display:flex;align-items:center;gap:9px">
          <?php if(!empty($p->image_url)):?><img src="<?php echo esc_url($p->image_url);?>" style="width:34px;height:42px;object-fit:cover;border-radius:6px;border:1px solid var(--border)" alt="" onerror="this.style.display='none'"><?php else:?><div style="width:34px;height:42px;background:var(--surface2);border-radius:6px;border:1px solid var(--border)"></div><?php endif;?>
          <span style="font-weight:500;color:var(--text1)"><?php echo esc_html($p->name);?></span>
        </div>
      </td>
      <td style="font-weight:600"><?php echo intval($p->units_sold);?></td>
      <td class="nc-amount">PKR <?php echo number_format($p->revenue,0);?></td>
      <td>
        <div class="nc-share-bar-wrap">
          <div class="nc-share-track"><div class="nc-share-fill" style="width:<?php echo $share;?>%"></div></div>
          <span class="nc-share-pct"><?php echo $share;?>%</span>
        </div>
      </td>
    </tr>
    <?php endforeach;?>
    </tbody>
  </table>
  </div>
  <?php endif;?>
</div>

</div><!-- /.nc-wrap -->
</div><!-- .wrap -->

<script>
var ncRevMonthData={labels:<?php echo $ml;?>,revenue:<?php echo $mr;?>,orders:<?php echo $mo;?>};
var ncRevDayData  ={labels:<?php echo $dl;?>,revenue:<?php echo $dr;?>};
var ncMainChart=null, ncGaugeChart=null;

document.addEventListener('DOMContentLoaded',function(){
  if(typeof Chart==='undefined')return;
  Chart.defaults.font.family="'Inter',sans-serif";

  // ── Main chart ────────────────────────────────────
  var mctx=document.getElementById('main-chart').getContext('2d');
  ncMainChart=new Chart(mctx,{
    type:'bar',
    data:{
      labels:ncRevMonthData.labels,
      datasets:[
        {label:'Revenue',data:ncRevMonthData.revenue,backgroundColor:'rgba(29,52,97,.12)',borderColor:'#1d3461',borderWidth:2,borderRadius:4,order:2,yAxisID:'y'},
        {label:'Orders',data:ncRevMonthData.orders,type:'line',borderColor:'#c9a227',backgroundColor:'transparent',tension:.4,pointRadius:4,pointBackgroundColor:'#c9a227',pointBorderColor:'#fff',pointBorderWidth:2,borderWidth:2,order:1,yAxisID:'y2'}
      ]
    },
    options:{responsive:true,interaction:{mode:'index',intersect:false},plugins:{legend:{display:false},tooltip:{backgroundColor:'#101828',padding:12,cornerRadius:8,callbacks:{label:function(c){if(c.datasetIndex===0)return' Revenue: PKR '+c.parsed.y.toLocaleString();return' Orders: '+c.parsed.y;}}}},
    scales:{x:{grid:{display:false},ticks:{font:{size:11},color:'#98a2b3'}},y:{grid:{color:'rgba(0,0,0,.04)'},ticks:{callback:function(v){return'PKR '+v.toLocaleString();},font:{size:11},color:'#98a2b3',maxTicksLimit:5}},y2:{position:'right',grid:{display:false},ticks:{font:{size:11},color:'#c9a227'}}}}
  });

  // ── Gauge / half-donut ────────────────────────────
  var gctx=document.getElementById('gauge-chart').getContext('2d');
  var rate=<?php echo NC_Analytics::conversion_rate();?>;
  ncGaugeChart=new Chart(gctx,{
    type:'doughnut',
    data:{datasets:[{data:[rate,100-rate],backgroundColor:['#1d3461','#f1f5f9'],borderWidth:0,circumference:180,rotation:-90}]},
    options:{responsive:false,cutout:'78%',plugins:{legend:{display:false},tooltip:{enabled:false}}}
  });

  // ── Status donut ──────────────────────────────────
  var sctx=document.getElementById('status-donut').getContext('2d');
  new Chart(sctx,{
    type:'doughnut',
    data:{
      labels:<?php echo $slabels;?>,
      datasets:[{data:<?php echo $scounts;?>,backgroundColor:['#12b76a','#2e90fa','#7f56d9','#f79009','#f04438'],borderWidth:2,borderColor:'#fff'}]
    },
    options:{responsive:true,cutout:'65%',plugins:{legend:{display:false},tooltip:{backgroundColor:'#101828',padding:10,cornerRadius:8}}}
  });
});

// ── Range toggle ──────────────────────────────────────
window.ncUpdateCharts=function(data){
  if(!ncMainChart)return;
  ncMainChart.data.labels=data.labels;
  ncMainChart.data.datasets[0].data=data.revenue;
  ncMainChart.data.datasets[1].data=data.orders||[];
  ncMainChart.update();
};
document.querySelectorAll('.nc-chip[data-range]').forEach(function(btn){
  btn.addEventListener('click',function(){
    document.querySelectorAll('.nc-chip[data-range]').forEach(function(b){b.classList.remove('active');});
    this.classList.add('active');
    var range=this.dataset.range;
    if(range==='today'){
      ncMainChart.data.labels=ncRevDayData.labels;
      ncMainChart.data.datasets[0].data=ncRevDayData.revenue;
      ncMainChart.data.datasets[1].data=[];
      ncMainChart.update();
    } else {
      jQuery.post(nc_admin.ajax_url,{action:'nc_get_analytics',nonce:nc_admin.nonce,range:range},function(r){
        if(r.success)window.ncUpdateCharts(r.data);
      });
    }
  });
});

// ── CSV exports ───────────────────────────────────────
function ncExportRevenueCSV(){
  var d=ncMainChart.data;
  var rows=[['Month','Revenue (PKR)','Orders']];
  d.labels.forEach(function(l,i){rows.push([l,d.datasets[0].data[i]||0,d.datasets[1].data[i]||0]);});
  ncDownloadCSV(rows,'nabirosa-revenue');
  document.querySelector('.nc-export-wrap').classList.remove('open');
}
function ncExportTopProductsCSV(){
  var rows=[['Rank','Product','Units Sold','Revenue (PKR)','Share %']];
  document.querySelectorAll('#nc-products-table tbody tr').forEach(function(tr,i){
    var tds=tr.querySelectorAll('td');
    if(!tds.length)return;
    rows.push([
      i+1,
      (tds[1].querySelector('span[style]')?.textContent||tds[1].textContent).trim(),
      tds[2].textContent.trim(),
      tds[3].textContent.replace('PKR ','').trim(),
      tds[4].textContent.trim()
    ]);
  });
  ncDownloadCSV(rows,'nabirosa-top-products');
  document.querySelector('.nc-export-wrap').classList.remove('open');
}
function ncDownloadCSV(rows,name){
  var csv=rows.map(function(r){return r.map(function(c){return '"'+(c||'').toString().replace(/"/g,'""')+'"';}).join(',');}).join('\n');
  var a=document.createElement('a');
  a.href='data:text/csv;charset=utf-8,\uFEFF'+encodeURIComponent(csv);
  a.download=name+'-'+new Date().toISOString().slice(0,10)+'.csv';
  a.click();
}
</script>

<style>
/* ── Analytics print styles ─────────────────────────────── */
@media print {
  #wpadminbar, #adminmenumain, #adminmenuback, .nc-sidebar,
  .nc-page-actions, .nc-chips, .nc-export-wrap,
  .nc-analytics-grid-3 .nc-card:nth-child(2),
  .nc-analytics-grid-3 .nc-card:nth-child(3) { display:none !important; }

  html, body { margin:0!important; padding:0!important; background:#fff!important; }
  #wpwrap,#wpcontent,#wpbody,#wpbody-content,.wrap.nc-admin,.nc-wrap {
    margin:0!important; padding:0!important; width:100%!important;
    background:#fff!important; overflow:visible!important;
  }

  /* KPI row: 2 per row on print */
  .nc-kpi-row { grid-template-columns:1fr 1fr !important; gap:10px !important; margin-bottom:14px !important; }
  .nc-kpi { box-shadow:none !important; border:1px solid #ddd !important; }

  /* Charts: show static image snapshots, hide canvas */
  .nc-print-chart-img { display:block !important; width:100% !important; }
  .nc-chart-canvas-wrap canvas { display:none !important; }

  /* Cards */
  .nc-card { box-shadow:none!important; border:1px solid #ddd!important; page-break-inside:avoid; }
  .nc-analytics-grid-2 { grid-template-columns:1fr !important; }
  .nc-analytics-grid-3 { grid-template-columns:1fr !important; }

  /* Show print summary table */
  .nc-print-summary { display:block !important; }

  @page { margin:12mm; size:A4; }
}

.nc-print-chart-img { display:none; width:100%; border-radius:8px; }
.nc-print-summary   { display:none; }
</style>

<script>
// Convert Chart.js canvases to static images before printing
window.addEventListener('beforeprint', function(){
  document.querySelectorAll('canvas').forEach(function(c){
    var existing = c.parentNode.querySelector('.nc-print-chart-img');
    if(existing) existing.remove();
    var img = document.createElement('img');
    img.className='nc-print-chart-img';
    img.src = c.toDataURL('image/png');
    img.style.width='100%';
    c.parentNode.insertBefore(img, c.nextSibling);
  });
});
window.addEventListener('afterprint', function(){
  document.querySelectorAll('.nc-print-chart-img').forEach(function(img){ img.remove(); });
});
</script>
