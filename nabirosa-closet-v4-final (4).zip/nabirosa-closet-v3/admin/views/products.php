<?php if(!defined('ABSPATH'))exit;

$save_notice='';
if(isset($_POST['nc_product_nonce'])&&wp_verify_nonce($_POST['nc_product_nonce'],'nc_save_product')){
    $pid=intval($_POST['product_id']??0);
    NC_Products::save($_POST,$pid?:null);
    $save_notice=$pid?'updated':'added';
}
if(isset($_GET['delete_product'])&&check_admin_referer('nc_delete_product')){
    NC_Products::delete(intval($_GET['delete_product']));
    $save_notice='deleted';
}
$products=NC_Products::get_all();

function nc_i($n,$s=16,$c='currentColor'){
  $d=['plus'=>'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>','edit'=>'<path d="M11 4H4a2 2 0 00-2 2v16a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>','trash'=>'<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>','x'=>'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>','img'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>','vid'=>'<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>','ok'=>'<polyline points="20 6 9 17 4 12"/>','star'=>'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>','lock'=>'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>','tag'=>'<path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>','link'=>'<path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/>'];
  return '<svg xmlns="http://www.w3.org/2000/svg" width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" stroke="'.$c.'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'.($d[$n]??'').'</svg>';
}
?>
<style>
/* ══ PRODUCTS PAGE SCOPED STYLES ══════════════════════════════ */
.nc-prod-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px}
.nc-pcard{background:#fff;border:1px solid var(--border);border-radius:var(--r12);overflow:hidden;transition:box-shadow .15s,transform .15s;display:flex;flex-direction:column}
.nc-pcard:hover{box-shadow:var(--shadow-md);transform:translateY(-2px)}
.nc-pmedia{position:relative;width:100%;aspect-ratio:3/4;background:#f6f7f9;overflow:hidden;flex-shrink:0}
.nc-pmedia-track{display:flex;height:100%;transition:transform .26s ease}
.nc-pmedia-slide{flex-shrink:0;width:100%;height:100%}
.nc-pmedia-slide img,.nc-pmedia-slide video{width:100%;height:100%;object-fit:cover;display:block}
.nc-parrow{position:absolute;top:50%;transform:translateY(-50%);width:26px;height:26px;background:rgba(255,255,255,.92);border:none;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .13s;box-shadow:0 1px 4px rgba(0,0,0,.15);z-index:2}
.nc-pmedia:hover .nc-parrow{opacity:1}
.nc-parrow-l{left:7px}.nc-parrow-r{right:7px}
.nc-pdots{position:absolute;bottom:8px;left:50%;transform:translateX(-50%);display:flex;gap:4px;z-index:2}
.nc-pdot{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.5);border:none;cursor:pointer;padding:0;transition:background .13s}
.nc-pdot.on{background:#fff;width:14px;border-radius:3px}
.nc-pbody{padding:12px 14px 8px;flex:1;min-width:0}
.nc-pname{font-weight:600;font-size:13px;color:var(--text1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:4px}
.nc-pprice{font-weight:700;font-size:14px;color:var(--navy)}
.nc-porig{font-size:12px;color:var(--text4);text-decoration:line-through;margin-left:5px}
.nc-ptags{display:flex;flex-wrap:wrap;gap:4px;margin-top:7px}
.nc-ptag{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:700}
.nc-ptag-sale{background:#fffaeb;color:#b54708}
.nc-ptag-new{background:#ecfdf3;color:#027a48}
.nc-ptag-soon{background:#f6f7f9;color:#667085}
.nc-pfoot{padding:8px 10px 10px;display:flex;gap:6px;border-top:1px solid var(--border);margin-top:auto}
.nc-pempty{background:#fff;border:1px solid var(--border);border-radius:var(--r12);padding:52px 20px;text-align:center;color:var(--text4)}
.nc-pempty svg{opacity:.2;margin-bottom:12px}
.nc-pempty h3{font-size:14px;font-weight:600;color:var(--text3);margin:0 0 4px}

/* ══ DRAWER OVERLAY ══════════════════════════════════════════ */
.ncd-overlay{position:fixed;inset:0;z-index:9999;background:rgba(16,24,40,.45);display:none;backdrop-filter:blur(2px)}
.ncd-overlay.open{display:flex;justify-content:flex-end}
.ncd-drawer{width:520px;max-width:100vw;background:#fff;display:flex;flex-direction:column;height:100vh;box-shadow:-16px 0 40px rgba(0,0,0,.12);animation:drawerSlide .22s cubic-bezier(.4,0,.2,1)}
@keyframes drawerSlide{from{transform:translateX(100%)}to{transform:translateX(0)}}
@media(max-width:600px){.ncd-drawer{width:100vw}}

/* Drawer sections */
.ncd-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);flex-shrink:0;background:#fff}
.ncd-title{font-size:15px;font-weight:700;color:var(--text1);margin:0}
.ncd-close{width:32px;height:32px;display:flex;align-items:center;justify-content:center;border:none;background:var(--surface2);border-radius:var(--r8);cursor:pointer;transition:background .13s}
.ncd-close:hover{background:var(--border)}
.ncd-body{flex:1;overflow-y:auto;padding:0;scrollbar-width:thin}
.ncd-foot{padding:14px 20px;border-top:1px solid var(--border);display:flex;gap:8px;justify-content:flex-end;background:#f9fafb;flex-shrink:0}

/* Section labels inside drawer */
.ncd-section{padding:16px 20px 0}
.ncd-section-label{font-size:11px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:.6px;margin:0 0 12px;display:flex;align-items:center;gap:6px}
.ncd-divider{border:none;border-top:1px solid var(--border);margin:16px 0 0}

/* Media grid */
.ncd-media-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
.ncd-slot{position:relative;aspect-ratio:3/4;border:1.5px dashed var(--border);border-radius:var(--r8);background:#f9fafb;overflow:hidden;cursor:pointer;transition:border-color .14s,background .14s;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px}
.ncd-slot:hover{border-color:var(--blue);background:#eff6ff}
.ncd-slot.filled{border-style:solid;border-color:var(--border)}
.ncd-slot-img,.ncd-slot-vid{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:calc(var(--r8) - 1px);display:none}
.ncd-slot.filled .ncd-slot-img,.ncd-slot.filled .ncd-slot-vid{display:block}
.ncd-slot-mask{position:absolute;inset:0;background:rgba(29,52,97,.55);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .14s;border-radius:calc(var(--r8) - 1px)}
.ncd-slot:hover .ncd-slot-mask{opacity:1}
.ncd-slot-lbl{font-size:10px;font-weight:600;color:var(--text4);text-align:center;line-height:1.4;z-index:1}
.ncd-slot-x{position:absolute;top:4px;right:4px;width:20px;height:20px;background:#fff;border-radius:50%;border:none;cursor:pointer;display:none;align-items:center;justify-content:center;box-shadow:0 1px 3px rgba(0,0,0,.2);z-index:3;transition:background .1s}
.ncd-slot-x:hover{background:#fee2e2}
.ncd-slot.filled:hover .ncd-slot-x{display:flex}

/* URL input rows */
.ncd-url-row{display:flex;align-items:center;gap:7px;margin-bottom:7px}
.ncd-url-row .nc-input{flex:1;font-size:12px;padding:7px 10px}
.ncd-url-row .nc-input.ok{border-color:#12b76a;background:#f0fdf4}
.ncd-url-row .nc-input.err{border-color:#f04438;background:#fff1f3}
.ncd-prev-btn{flex-shrink:0;padding:7px 10px;font-size:12px;border-radius:var(--r6);background:var(--surface2);border:1px solid var(--border);cursor:pointer;font-family:'Inter',sans-serif;font-weight:500;color:var(--text2);transition:all .13s;white-space:nowrap}
.ncd-prev-btn:hover{background:var(--border);color:var(--text1)}
.ncd-prev-btn.loaded{background:#ecfdf3;border-color:#abefc6;color:#027a48}

/* Fields */
.ncd-field{margin-bottom:12px}
.ncd-field label{display:flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:var(--text2);margin-bottom:5px}
.ncd-field label .req{color:#ef4444;font-weight:400;font-size:11px}
.ncd-field label small{font-weight:400;color:var(--text4);font-size:11px;margin-left:2px}
.ncd-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.ncd-checkbox{display:flex;align-items:center;gap:9px;padding:10px 12px;border-radius:var(--r8);border:1px solid var(--border);background:#f9fafb;cursor:pointer;font-size:13px;font-weight:500;color:var(--text2);margin-bottom:8px;transition:all .13s;user-select:none}
.ncd-checkbox:hover{border-color:var(--navy);background:#fff}
.ncd-checkbox input{width:15px;height:15px;accent-color:var(--navy);cursor:pointer;flex-shrink:0}
.ncd-checkbox.checked{border-color:var(--navy);background:#eef2ff;color:var(--navy)}

/* Price preview */
.ncd-price-preview{background:#f6f7f9;border-radius:var(--r8);padding:10px 12px;font-size:12px;color:var(--text3);border:1px solid var(--border);margin-top:6px;display:none}
.ncd-price-preview.show{display:flex;align-items:center;gap:8px}
.ncd-price-main{font-size:15px;font-weight:700;color:var(--navy)}
.ncd-price-orig{font-size:13px;color:var(--text4);text-decoration:line-through}
.ncd-price-disc{font-size:11px;font-weight:700;color:#027a48;background:#ecfdf3;padding:2px 6px;border-radius:10px}

/* Submit spinner */
.ncd-spinner{display:none;width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
</style>

<div class="wrap nc-admin">

<!-- Sidebar -->
<nav class="nc-sidebar">
  <div class="nc-sidebar-brand">
    <div class="nc-sidebar-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg></div>
    <div><div class="nc-sidebar-brand-name">Nabirosa Closet</div><div class="nc-sidebar-brand-sub">Admin v4</div></div>
  </div>
  <div class="nc-sidebar-nav">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-dashboard');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>Dashboard</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Analytics</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Orders<?php if(!empty($stats['pending'])&&$stats['pending']>0):?><span class="nc-nav-badge"><?php echo $stats['pending'];?></span><?php endif;?></a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-products');?>" class="nc-nav-item active"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>Products</a>
  </div>
  <div class="nc-sidebar-footer"><a href="<?php echo home_url('/');?>" target="_blank" class="nc-nav-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>View Store</a></div>
</nav>

<div class="nc-wrap">

<?php if($save_notice==='added'):?><div class="nc-notice nc-notice-ok"><?php echo nc_i('ok',13,'#027a48');?> Product added successfully.</div><?php endif;?>
<?php if($save_notice==='updated'):?><div class="nc-notice nc-notice-ok"><?php echo nc_i('ok',13,'#027a48');?> Product updated.</div><?php endif;?>
<?php if($save_notice==='deleted'):?><div class="nc-notice nc-notice-ok"><?php echo nc_i('ok',13,'#027a48');?> Product deleted.</div><?php endif;?>

<div class="nc-page-header">
  <div>
    <h1 class="nc-page-title">Products</h1>
    <p class="nc-page-sub"><?php echo count($products);?> item<?php echo count($products)!==1?'s':'';?> in catalogue</p>
  </div>
  <div class="nc-page-actions">
    <button class="nc-btn nc-btn-primary" id="ncd-open" type="button">
      <?php echo nc_i('plus',14,'#fff');?> Add Product
    </button>
  </div>
</div>

<!-- Grid -->
<?php if(empty($products)):?>
<div class="nc-pempty">
  <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
  <h3>No products yet</h3>
  <p>Click "Add Product" to add your first item to the catalogue.</p>
</div>
<?php else:?>
<div class="nc-prod-grid">
<?php foreach($products as $p):
  $disc=''; if($p->orig_price&&$p->price<$p->orig_price) $disc=round((1-$p->price/$p->orig_price)*100).'% off';
  $media=[];
  if(!empty($p->image_url))  $media[]=['type'=>'img','src'=>$p->image_url];
  if(!empty($p->image2_url)) $media[]=['type'=>'img','src'=>$p->image2_url];
  if(!empty($p->image3_url)) $media[]=['type'=>'img','src'=>$p->image3_url];
  if(!empty($p->video_url))  $media[]=['type'=>'vid','src'=>$p->video_url];
  if(empty($media))          $media[]=['type'=>'ph','src'=>''];
?>
<div class="nc-pcard">
  <div class="nc-pmedia" data-count="<?php echo count($media);?>">
    <div class="nc-pmedia-track">
    <?php foreach($media as $m):?>
      <div class="nc-pmedia-slide">
        <?php if($m['type']==='img'):?>
          <img src="<?php echo esc_url($m['src']);?>" alt="<?php echo esc_attr($p->name);?>" loading="lazy" onerror="this.src='https://placehold.co/300x400/f6f7f9/ccc?text=?'">
        <?php elseif($m['type']==='vid'):?>
          <video src="<?php echo esc_url($m['src']);?>" muted playsinline loop></video>
        <?php else:?>
          <img src="https://placehold.co/300x400/f6f7f9/d0d5dd?text=No+Image" alt="">
        <?php endif;?>
      </div>
    <?php endforeach;?>
    </div>
    <?php if(count($media)>1):?>
    <button class="nc-parrow nc-parrow-l" type="button"><?php echo nc_i('x',0);?><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg></button>
    <button class="nc-parrow nc-parrow-r" type="button"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></button>
    <div class="nc-pdots">
      <?php for($i=0;$i<count($media);$i++):?>
      <button class="nc-pdot<?php echo $i===0?' on':'';?>" data-i="<?php echo $i;?>" type="button"></button>
      <?php endfor;?>
    </div>
    <?php endif;?>
  </div>
  <div class="nc-pbody">
    <div class="nc-pname" title="<?php echo esc_attr($p->name);?>"><?php echo esc_html($p->name);?></div>
    <div>
      <span class="nc-pprice">PKR <?php echo number_format($p->price,0);?></span>
      <?php if($p->orig_price):?><span class="nc-porig">PKR <?php echo number_format($p->orig_price,0);?></span><?php endif;?>
    </div>
    <div class="nc-ptags">
      <?php if($disc):?><span class="nc-ptag nc-ptag-sale"><?php echo $disc;?></span><?php endif;?>
      <?php if($p->badge):?><span class="nc-ptag nc-ptag-sale"><?php echo esc_html($p->badge);?></span><?php endif;?>
      <?php if($p->is_new_arrival):?><span class="nc-ptag nc-ptag-new">New Arrival</span><?php endif;?>
      <?php if($p->is_coming_soon):?><span class="nc-ptag nc-ptag-soon">Coming Soon</span><?php endif;?>
    </div>
  </div>
  <div class="nc-pfoot">
    <button type="button" class="nc-btn nc-btn-outline nc-btn-sm" style="flex:1;justify-content:center" data-edit='<?php echo esc_attr(json_encode($p));?>'>
      <?php echo nc_i('edit',13);?> Edit
    </button>
    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=nabirosa-products&delete_product='.$p->id),'nc_delete_product');?>"
       class="nc-btn nc-btn-danger nc-btn-sm nc-btn-icon"
       title="Delete" onclick="return confirm('Delete \'<?php echo esc_js($p->name);?>\'?')">
      <?php echo nc_i('trash',13,'#b42318');?>
    </a>
  </div>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<!-- ══════════════════════════
     SLIDE DRAWER
     ══════════════════════════ -->
<div class="ncd-overlay" id="ncd-overlay">
<div class="ncd-drawer" id="ncd-drawer" role="dialog" aria-modal="true" aria-labelledby="ncd-title">

  <div class="ncd-head">
    <h2 class="ncd-title" id="ncd-title">Add Product</h2>
    <button class="ncd-close" id="ncd-close" type="button" aria-label="Close">
      <?php echo nc_i('x',14,'#667085');?>
    </button>
  </div>

  <div class="ncd-body">
  <form method="post" id="ncd-form">
    <?php wp_nonce_field('nc_save_product','nc_product_nonce');?>
    <input type="hidden" name="product_id" id="ncd-pid" value="">

    <!-- ── Media ───────────────────────── -->
    <div class="ncd-section">
      <p class="ncd-section-label"><?php echo nc_i('img',13,'#667085');?> Images &amp; Video</p>

      <div class="ncd-media-grid">
        <?php
        $slots=[
          ['img1','Image 1','img','Primary'],
          ['img2','Image 2','img',''],
          ['img3','Image 3','img',''],
          ['vid', 'Video',  'vid','mp4/webm'],
        ];
        foreach($slots as[$key,$lbl,$icon,$sub]):?>
        <div class="ncd-slot" id="nds-<?php echo $key;?>" title="Click to preview after entering URL">
          <?php if($icon==='img'):?>
          <img class="ncd-slot-img" id="ndp-<?php echo $key;?>" src="" alt="">
          <?php else:?>
          <video class="ncd-slot-vid" id="ndp-<?php echo $key;?>" muted loop playsinline></video>
          <?php endif;?>
          <div class="ncd-slot-mask"><?php echo nc_i($icon,18,'#fff');?></div>
          <div style="z-index:1;display:flex;flex-direction:column;align-items:center;gap:3px">
            <?php echo nc_i($icon,20,'#d0d5dd');?>
            <span class="ncd-slot-lbl"><?php echo $lbl;?><?php if($sub):?><br><span style="color:#d0d5dd;font-size:9px"><?php echo $sub;?></span><?php endif;?></span>
          </div>
          <button class="ncd-slot-x" type="button" data-slot="<?php echo $key;?>" title="Remove"><?php echo nc_i('x',8,'#b42318');?></button>
        </div>
        <?php endforeach;?>
      </div>

      <div>
        <?php
        $urlfields=[
          ['img1','image_url', 'img','Image 1 URL (primary)'],
          ['img2','image2_url','img','Image 2 URL'],
          ['img3','image3_url','img','Image 3 URL'],
          ['vid', 'video_url', 'vid','Video URL — .mp4 or .webm'],
        ];
        foreach($urlfields as[$slot,$fname,$icon,$ph]):?>
        <div class="ncd-url-row">
          <?php echo nc_i($icon,13,'#98a2b3');?>
          <input class="nc-input" type="url" name="<?php echo $fname;?>" id="ndf-<?php echo $fname;?>"
                 placeholder="<?php echo $ph;?>"
                 data-slot="<?php echo $slot;?>">
          <button class="ncd-prev-btn" type="button" data-prev="<?php echo $slot;?>" data-field="ndf-<?php echo $fname;?>">Preview</button>
        </div>
        <?php endforeach;?>
      </div>
    </div>

    <hr class="ncd-divider">

    <!-- ── Basic info ───────────────────── -->
    <div class="ncd-section">
      <p class="ncd-section-label"><?php echo nc_i('tag',13,'#667085');?> Basic Info</p>

      <div class="ncd-field">
        <label><?php echo nc_i('link',12,'#667085');?> Product Name <span class="req">*</span></label>
        <input class="nc-input" type="text" name="name" id="ndf-name" placeholder="e.g. Handmade Embroidered Kurti" required>
      </div>

      <div class="ncd-2col">
        <div class="ncd-field">
          <label>Sale Price (PKR) <span class="req">*</span></label>
          <input class="nc-input" type="number" name="price" id="ndf-price" placeholder="3200" min="0" required>
        </div>
        <div class="ncd-field">
          <label>Original Price <small>(optional)</small></label>
          <input class="nc-input" type="number" name="orig_price" id="ndf-orig" placeholder="4500" min="0">
        </div>
      </div>

      <!-- Live price preview -->
      <div class="ncd-price-preview" id="ndd-price-preview">
        <span class="ndd-pico"><?php echo nc_i('tag',13,'#027a48');?></span>
        <span class="ndd-sale"></span>
        <span class="ndd-orig" style="display:none"></span>
        <span class="ndd-disc" style="display:none"></span>
      </div>

      <div class="ncd-field" style="margin-top:10px">
        <label>Description</label>
        <textarea class="nc-input" name="description" id="ndf-desc" rows="3" placeholder="Short product description…" style="resize:vertical;min-height:72px;font-family:'Inter',sans-serif"></textarea>
      </div>
    </div>

    <hr class="ncd-divider">

    <!-- ── Display ──────────────────────── -->
    <div class="ncd-section">
      <p class="ncd-section-label"><?php echo nc_i('star',13,'#667085');?> Display Options</p>

      <div class="ncd-2col">
        <div class="ncd-field">
          <label>Badge <small>On Sale, New…</small></label>
          <input class="nc-input" type="text" name="badge" id="ndf-badge" placeholder="e.g. Just In">
        </div>
        <div class="ncd-field">
          <label>Sort Order</label>
          <input class="nc-input" type="number" name="sort_order" id="ndf-sort" value="0" min="0">
        </div>
      </div>
      <div class="ncd-field">
        <label>Meta Tags <small>comma-separated</small></label>
        <input class="nc-input" type="text" name="meta_tags" id="ndf-tags" placeholder="Hand Embroidered, Premium Fabric, Lawn">
      </div>
    </div>

    <hr class="ncd-divider">

    <!-- ── Flags ────────────────────────── -->
    <div class="ncd-section" style="padding-bottom:20px">
      <p class="ncd-section-label"><?php echo nc_i('ok',13,'#667085');?> Visibility Flags</p>

      <label class="ndc-checkbox-wrap ndd-check" id="ndd-new-label">
        <input type="checkbox" name="is_new_arrival" id="ndf-new" value="1">
        <?php echo nc_i('star',14,'#c9a227');?>
        Show in New Arrivals
      </label>
      <label class="ndc-checkbox-wrap ndd-check" id="ndd-soon-label">
        <input type="checkbox" name="is_coming_soon" id="ndf-soon" value="1">
        <?php echo nc_i('lock',14,'#667085');?>
        Mark as Coming Soon
      </label>
    </div>

  </form>
  </div><!-- /.ncd-body -->

  <div class="ncd-foot">
    <button type="button" class="nc-btn nc-btn-outline" id="ncd-cancel">Cancel</button>
    <button type="submit" form="ncd-form" class="nc-btn nc-btn-primary" id="ncd-submit">
      <?php echo nc_i('ok',14,'#fff');?>
      <span id="ndd-lbl">Add Product</span>
      <span class="ncd-spinner" id="ndd-spin"></span>
    </button>
  </div>

</div><!-- /.ncd-drawer -->
</div><!-- /.ncd-overlay -->

</div><!-- /.nc-wrap -->
</div><!-- .wrap -->

<style>
.ndc-checkbox-wrap{display:flex;align-items:center;gap:9px;padding:10px 12px;border-radius:var(--r8);border:1px solid var(--border);background:#f9fafb;cursor:pointer;font-size:13px;font-weight:500;color:var(--text2);margin-bottom:8px;transition:all .13s;user-select:none}
.ndc-checkbox-wrap:hover{border-color:var(--navy);background:#fff}
.ndc-checkbox-wrap input{width:15px;height:15px;accent-color:var(--navy);cursor:pointer;flex-shrink:0}
</style>

<script>
(function(){
'use strict';

var overlay  = document.getElementById('ncd-overlay');
var titleEl  = document.getElementById('ncd-title');
var lblEl    = document.getElementById('ndd-lbl');
var spinEl   = document.getElementById('ndd-spin');
var pidInput = document.getElementById('ncd-pid');
var form     = document.getElementById('ncd-form');

/* ── Open / Close ────────────────────────────────── */
function openDrawer(title, btn){
  titleEl.textContent = title;
  lblEl.textContent   = btn;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(function(){ document.getElementById('ndf-name').focus(); }, 250);
}
function closeDrawer(){
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

document.getElementById('ncd-open').addEventListener('click',  function(){ resetForm(); openDrawer('Add New Product','Add Product'); });
document.getElementById('ncd-close').addEventListener('click',  closeDrawer);
document.getElementById('ncd-cancel').addEventListener('click', closeDrawer);
overlay.addEventListener('click', function(e){ if(e.target===overlay) closeDrawer(); });
document.addEventListener('keydown', function(e){ if(e.key==='Escape'&&overlay.classList.contains('open')) closeDrawer(); });

/* ── Reset ───────────────────────────────────────── */
function resetForm(){
  form.reset();
  pidInput.value='';
  ['img1','img2','img3','vid'].forEach(clearSlot);
  updatePricePreview();
}

/* ── Slot helpers ────────────────────────────────── */
function setSlot(key, url){
  if(!url){ clearSlot(key); return; }
  var slot  = document.getElementById('nds-'+key);
  var prev  = document.getElementById('ndp-'+key);
  if(!slot||!prev) return;
  slot.classList.add('filled');
  if(key==='vid'){
    prev.src=url; prev.load&&prev.load();
  } else {
    prev.src=url;
  }
}
function clearSlot(key){
  var slot  = document.getElementById('nds-'+key);
  var prev  = document.getElementById('ndp-'+key);
  if(slot)  slot.classList.remove('filled');
  if(prev){ prev.src=''; if(key==='vid'&&prev.load) prev.load(); }
  // also clear corresponding URL input
  var fieldMap={'img1':'ndf-image_url','img2':'ndf-image2_url','img3':'ndf-image3_url','vid':'ndf-video_url'};
  var f=document.getElementById(fieldMap[key]);
  if(f){ f.value=''; f.classList.remove('ok','err'); }
  // reset preview button
  var btn=document.querySelector('[data-prev="'+key+'"]');
  if(btn) btn.classList.remove('loaded');
}

/* Remove X buttons */
document.querySelectorAll('.ncd-slot-x').forEach(function(btn){
  btn.addEventListener('click',function(e){ e.stopPropagation(); clearSlot(this.dataset.slot); });
});

/* Preview buttons */
document.querySelectorAll('[data-prev]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var key   = this.dataset.prev;
    var field = document.getElementById(this.dataset.field);
    var url   = field&&field.value.trim();
    if(!url) return;
    setSlot(key, url);
    field.classList.add('ok'); field.classList.remove('err');
    this.classList.add('loaded');
    this.textContent = '✓ Loaded';
    var self=this; setTimeout(function(){ self.textContent='Preview'; self.classList.remove('loaded'); }, 2000);
  });
});

/* Auto-preview on paste */
document.querySelectorAll('.nc-input[data-slot]').forEach(function(inp){
  inp.addEventListener('paste', function(){
    var slot=this.dataset.slot, self=this;
    setTimeout(function(){
      var url=self.value.trim();
      if(url.startsWith('http')){
        setSlot(slot, url);
        self.classList.add('ok'); self.classList.remove('err');
        var btn=document.querySelector('[data-prev="'+slot+'"]');
        if(btn){ btn.classList.add('loaded'); btn.textContent='✓ Loaded'; setTimeout(function(){ btn.textContent='Preview'; btn.classList.remove('loaded'); },2000); }
      }
    },50);
  });
});

/* ── Live price preview ──────────────────────────── */
function updatePricePreview(){
  var sale = parseFloat(document.getElementById('ndf-price').value)||0;
  var orig = parseFloat(document.getElementById('ndf-orig').value)||0;
  var wrap = document.getElementById('ndd-price-preview');
  var saleEl = wrap.querySelector('.ndd-sale');
  var origEl = wrap.querySelector('.ndd-orig');
  var discEl = wrap.querySelector('.ndd-disc');
  if(!sale){ wrap.classList.remove('show'); return; }
  wrap.classList.add('show');
  saleEl.innerHTML='<strong style="font-size:15px;font-weight:700;color:var(--navy)">PKR '+sale.toLocaleString()+'</strong>';
  if(orig&&orig>sale){
    origEl.textContent='PKR '+orig.toLocaleString(); origEl.style.display='';
    discEl.textContent=Math.round((1-sale/orig)*100)+'% off'; discEl.style.display='';
  } else {
    origEl.style.display='none'; discEl.style.display='none';
  }
}
document.getElementById('ndf-price').addEventListener('input', updatePricePreview);
document.getElementById('ndf-orig').addEventListener('input',  updatePricePreview);

/* ── Checkbox UX ─────────────────────────────────── */
document.querySelectorAll('.ndc-checkbox-wrap input[type=checkbox]').forEach(function(cb){
  cb.addEventListener('change', function(){
    this.closest('.ndc-checkbox-wrap').classList.toggle('checked', this.checked);
  });
});

/* ── Submit spinner ──────────────────────────────── */
form.addEventListener('submit', function(){
  var btn=document.getElementById('ncd-submit');
  btn.disabled=true;
  lblEl.textContent='Saving…';
  spinEl.style.display='inline-block';
});

/* ── Edit product ────────────────────────────────── */
document.querySelectorAll('[data-edit]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var p=JSON.parse(this.dataset.edit);
    resetForm();
    pidInput.value=p.id||'';
    var map={'ndf-name':p.name,'ndf-price':p.price,'ndf-orig':p.orig_price||'',
             'ndf-desc':p.description,'ndf-badge':p.badge,'ndf-sort':p.sort_order||0,
             'ndf-tags':p.meta_tags,'ndf-image_url':p.image_url||'',
             'ndf-image2_url':p.image2_url||'','ndf-image3_url':p.image3_url||'','ndf-video_url':p.video_url||''};
    Object.keys(map).forEach(function(id){
      var el=document.getElementById(id);
      if(el) el.value=map[id]||'';
    });
    var newCb=document.getElementById('ndf-new');
    var soonCb=document.getElementById('ndf-soon');
    newCb.checked=!!parseInt(p.is_new_arrival);
    soonCb.checked=!!parseInt(p.is_coming_soon);
    newCb.closest('.ndc-checkbox-wrap').classList.toggle('checked',newCb.checked);
    soonCb.closest('.ndc-checkbox-wrap').classList.toggle('checked',soonCb.checked);
    if(p.image_url)  setSlot('img1',p.image_url);
    if(p.image2_url) setSlot('img2',p.image2_url);
    if(p.image3_url) setSlot('img3',p.image3_url);
    if(p.video_url)  setSlot('vid',p.video_url);
    updatePricePreview();
    openDrawer('Edit Product','Update Product');
  });
});

/* ── Product card carousel ───────────────────────── */
document.querySelectorAll('.nc-pmedia').forEach(function(wrap){
  var track=wrap.querySelector('.nc-pmedia-track');
  var dots=wrap.querySelectorAll('.nc-pdot');
  var pl=wrap.querySelector('.nc-parrow-l');
  var pr=wrap.querySelector('.nc-parrow-r');
  var n=parseInt(wrap.dataset.count)||1;
  var cur=0;
  if(n<=1) return;
  function go(idx){
    cur=(idx+n)%n;
    track.style.transform='translateX(-'+(cur*100)+'%)';
    dots.forEach(function(d,i){ d.classList.toggle('on',i===cur); });
  }
  pl&&pl.addEventListener('click',function(){ go(cur-1); });
  pr&&pr.addEventListener('click',function(){ go(cur+1); });
  dots.forEach(function(d){ d.addEventListener('click',function(){ go(parseInt(this.dataset.i)); }); });
});

})();
</script>
