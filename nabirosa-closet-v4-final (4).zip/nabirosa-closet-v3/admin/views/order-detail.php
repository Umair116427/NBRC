<?php if(!defined('ABSPATH'))exit;
$ini=strtoupper(substr($order->first_name,0,1).substr($order->last_name,0,1));
$pay_labels=['cod'=>'Cash on Delivery','bank'=>'Bank Transfer','jazzcash'=>'JazzCash / EasyPaisa'];
?>
<div class="wrap nc-admin">

<!-- Sidebar -->
<nav class="nc-sidebar">
  <div class="nc-sidebar-brand">
    <div class="nc-sidebar-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg></div>
    <div><div class="nc-sidebar-brand-name">Nabirosa Closet</div><div class="nc-sidebar-brand-sub">Admin v4</div></div>
  </div>
  <div class="nc-sidebar-nav">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-dashboard');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>Dashboard</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-analytics');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>Analytics</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-nav-item active"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Orders</a>
    <a href="<?php echo admin_url('admin.php?page=nabirosa-products');?>" class="nc-nav-item"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>Products</a>
  </div>
  <div class="nc-sidebar-footer"><a href="<?php echo home_url('/');?>" target="_blank" class="nc-nav-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>View Store</a></div>
</nav>

<div class="nc-wrap">

<!-- Header -->
<div class="nc-page-header" id="nc-screen-header">
  <div>
    <h1 class="nc-page-title"><?php echo esc_html($order->order_number);?></h1>
    <p class="nc-page-sub">Placed <?php echo date('d F Y \a\t H:i',strtotime($order->created_at));?></p>
  </div>
  <div class="nc-page-actions">
    <a href="<?php echo admin_url('admin.php?page=nabirosa-orders');?>" class="nc-btn nc-btn-outline nc-btn-sm">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
      All Orders
    </a>
    <button class="nc-btn nc-btn-outline nc-btn-sm" onclick="ncPrintInvoice()">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
      Print Invoice
    </button>
    <button class="nc-btn nc-btn-primary nc-btn-sm" onclick="ncPrintInvoice()">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      Download PDF
    </button>
  </div>
</div>

<!-- ══════════════════════════════════════════════════
     INVOICE — lives in DOM always, shown only on print
     Uses visibility trick (NOT display:none) so print works
     ══════════════════════════════════════════════════ -->
<div class="nc-invoice" id="nc-invoice">
  <!-- Brand header -->
  <div class="nc-inv-header">
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="width:44px;height:44px;background:#1d3461;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
      </div>
      <div>
        <div style="font-size:20px;font-weight:800;color:#1d3461;letter-spacing:-.3px">Nabirosa Closet</div>
        <div style="font-size:12px;color:#667085;margin-top:2px">Purana Kahna Nau, Lahore · @simply_nabila7</div>
      </div>
    </div>
    <div style="text-align:right">
      <div style="font-size:26px;font-weight:800;color:#1d3461;letter-spacing:-.5px">INVOICE</div>
      <div style="font-size:13px;color:#667085;margin-top:3px;font-family:monospace"><?php echo esc_html($order->order_number);?></div>
    </div>
  </div>

  <!-- Meta grid -->
  <div class="nc-inv-meta">
    <div class="nc-inv-meta-col">
      <div class="nc-inv-block-title">Bill To</div>
      <div style="font-weight:700;font-size:15px;color:#101828;margin-bottom:4px"><?php echo esc_html($order->first_name.' '.$order->last_name);?></div>
      <div style="font-size:13px;color:#344054;margin-bottom:2px"><?php echo esc_html($order->phone);?></div>
      <?php if($order->email):?><div style="font-size:13px;color:#344054;margin-bottom:2px"><?php echo esc_html($order->email);?></div><?php endif;?>
      <div style="font-size:13px;color:#344054"><?php echo esc_html($order->address.', '.$order->city);?></div>
    </div>
    <div class="nc-inv-meta-col">
      <div class="nc-inv-block-title">Invoice Details</div>
      <table class="nc-inv-details-tbl">
        <tr><td>Date</td><td><?php echo date('d F Y',strtotime($order->created_at));?></td></tr>
        <tr><td>Order #</td><td style="font-family:monospace;font-weight:600;color:#1d3461"><?php echo esc_html($order->order_number);?></td></tr>
        <tr><td>Payment</td><td><?php echo esc_html($pay_labels[$order->payment]??ucwords($order->payment));?></td></tr>
        <tr><td>Status</td><td><span style="background:<?php echo ['pending'=>'#fffaeb','processing'=>'#eff8ff','shipped'=>'#f9f5ff','delivered'=>'#ecfdf3','cancelled'=>'#fff1f3'][$order->status]??'#f6f7f9';?>;color:<?php echo ['pending'=>'#b54708','processing'=>'#175cd3','shipped'=>'#6941c6','delivered'=>'#027a48','cancelled'=>'#b42318'][$order->status]??'#344054';?>;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700"><?php echo esc_html(NC_Orders::$statuses[$order->status]??ucfirst($order->status));?></span></td></tr>
      </table>
    </div>
  </div>

  <!-- Items table -->
  <table class="nc-inv-items">
    <thead>
      <tr>
        <th>Item</th>
        <th style="text-align:right">Unit Price</th>
        <th style="text-align:center">Qty</th>
        <th style="text-align:right">Amount</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach(($order->items??[]) as $item):?>
    <tr>
      <td style="font-weight:500"><?php echo esc_html($item['name']);?></td>
      <td style="text-align:right;color:#344054">PKR <?php echo number_format($item['price'],0);?></td>
      <td style="text-align:center"><?php echo intval($item['qty']);?></td>
      <td style="text-align:right;font-weight:600">PKR <?php echo number_format($item['price']*$item['qty'],0);?></td>
    </tr>
    <?php endforeach;?>
    </tbody>
    <tfoot>
      <tr class="nc-inv-subtotal"><td colspan="3" style="text-align:right">Subtotal</td><td style="text-align:right">PKR <?php echo number_format($order->subtotal,0);?></td></tr>
      <tr class="nc-inv-subtotal"><td colspan="3" style="text-align:right">Shipping</td><td style="text-align:right">PKR <?php echo number_format($order->shipping,0);?></td></tr>
      <tr class="nc-inv-total"><td colspan="3" style="text-align:right;font-weight:800;font-size:14px">Total</td><td style="text-align:right;font-size:18px;font-weight:800;color:#1d3461">PKR <?php echo number_format($order->total,0);?></td></tr>
    </tfoot>
  </table>

  <?php if($order->notes):?>
  <div style="background:#f6f7f9;border-radius:8px;padding:12px 14px;font-size:13px;color:#344054;margin-top:16px"><strong>Notes:</strong> <?php echo esc_html($order->notes);?></div>
  <?php endif;?>

  <div class="nc-inv-footer">
    Thank you for shopping with Nabirosa Closet &nbsp;·&nbsp; @simply_nabila7 &nbsp;·&nbsp; Lahore, Pakistan
  </div>
</div><!-- /.nc-invoice -->

<!-- ── Screen-only detail layout ─── -->
<div id="nc-detail-screen">
<div class="nc-detail-layout">

  <div>
    <div class="nc-grid-2" style="margin-bottom:14px">
      <div class="nc-detail-infoblock">
        <div class="nc-ib-title"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>Customer</div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
          <div class="nc-avatar" style="width:36px;height:36px;font-size:13px"><?php echo esc_html($ini);?></div>
          <div><div style="font-weight:600;font-size:14px"><?php echo esc_html($order->first_name.' '.$order->last_name);?></div><div style="font-size:12px;color:var(--text3)"><?php echo esc_html($order->phone);?></div></div>
        </div>
        <?php if($order->email):?><div class="nc-ib-row"><span class="nc-ib-key">Email</span><span class="nc-ib-val"><?php echo esc_html($order->email);?></span></div><?php endif;?>
        <div class="nc-ib-row"><span class="nc-ib-key">City</span><span class="nc-ib-val"><?php echo esc_html($order->city);?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key">Address</span><span class="nc-ib-val"><?php echo esc_html($order->address);?></span></div>
        <?php if($order->postal):?><div class="nc-ib-row"><span class="nc-ib-key">Postal</span><span class="nc-ib-val"><?php echo esc_html($order->postal);?></span></div><?php endif;?>
      </div>
      <div class="nc-detail-infoblock">
        <div class="nc-ib-title"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Order Info</div>
        <div class="nc-ib-row"><span class="nc-ib-key">Order #</span><span class="nc-ib-val" style="font-family:monospace;color:var(--navy)"><?php echo esc_html($order->order_number);?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key">Date</span><span class="nc-ib-val"><?php echo date('d M Y, H:i',strtotime($order->created_at));?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key">Payment</span><span class="nc-ib-val"><?php echo esc_html($pay_labels[$order->payment]??ucwords($order->payment));?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key">Subtotal</span><span class="nc-ib-val">PKR <?php echo number_format($order->subtotal,0);?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key">Shipping</span><span class="nc-ib-val">PKR <?php echo number_format($order->shipping,0);?></span></div>
        <div class="nc-ib-row"><span class="nc-ib-key" style="font-weight:700">Total</span><span class="nc-ib-val" style="font-size:14px;font-weight:700;color:var(--navy)">PKR <?php echo number_format($order->total,0);?></span></div>
        <?php if($order->notes):?><div class="nc-ib-row"><span class="nc-ib-key">Notes</span><span class="nc-ib-val" style="color:var(--text3)"><?php echo esc_html($order->notes);?></span></div><?php endif;?>
      </div>
    </div>

    <div class="nc-card">
      <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Items Ordered</h3><span style="font-size:12px;color:var(--text3)"><?php echo count($order->items??[]);?> item<?php echo count($order->items??[])!==1?'s':'';?></span></div>
      <table class="nc-items-tbl">
        <thead><tr><th>Product</th><th>Unit Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
        <tbody>
        <?php foreach(($order->items??[]) as $item):?>
        <tr>
          <td><div class="nc-item-cell"><?php if(!empty($item['image'])):?><img class="nc-item-img" src="<?php echo esc_url($item['image']);?>" alt="" onerror="this.style.display='none'"><?php endif;?><span style="font-weight:500"><?php echo esc_html($item['name']);?></span></div></td>
          <td>PKR <?php echo number_format($item['price'],0);?></td>
          <td><span style="display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;background:var(--surface2);border-radius:6px;font-weight:700;font-size:12px;color:var(--navy)"><?php echo intval($item['qty']);?></span></td>
          <td style="font-weight:600">PKR <?php echo number_format($item['price']*$item['qty'],0);?></td>
        </tr>
        <?php endforeach;?>
        </tbody>
        <tfoot class="nc-total-tbl">
          <tr><td colspan="3" style="text-align:right;color:var(--text3);font-size:12px">Shipping</td><td>PKR <?php echo number_format($order->shipping,0);?></td></tr>
          <tr><td colspan="3" style="text-align:right;font-weight:700">Grand Total</td><td class="nc-grand-total">PKR <?php echo number_format($order->total,0);?></td></tr>
        </tfoot>
      </table>
    </div>
  </div>

  <div>
    <div class="nc-card" style="margin-bottom:14px">
      <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Update Status</h3></div>
      <div style="padding:14px">
        <div class="nc-status-opts" id="nc-status-opts">
          <?php foreach(NC_Orders::$statuses as $k=>$lbl): $sel=$order->status===$k;?>
          <label class="nc-sopt<?php echo $sel?' sel':'';?>">
            <input type="radio" name="nc_order_status" value="<?php echo $k;?>"<?php echo $sel?' checked':'';?>>
            <span class="nc-radio-ring"></span>
            <span class="nc-pill nc-s-<?php echo esc_attr($k);?>"><span class="nc-dot"></span><?php echo esc_html($lbl);?></span>
          </label>
          <?php endforeach;?>
        </div>
        <button id="nc-save-status" class="nc-btn nc-btn-primary" data-order-id="<?php echo $order->id;?>" style="width:100%;justify-content:center;margin-top:12px">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          Save Status
        </button>
        <div id="nc-status-result" style="margin-top:8px;text-align:center;font-size:12px"></div>
      </div>
    </div>
    <div class="nc-card">
      <div class="nc-card-header"><h3 class="nc-card-title"><span class="nc-card-title-badge"></span>Invoice</h3></div>
      <div style="padding:10px;display:flex;flex-direction:column;gap:6px">
        <button class="nc-btn nc-btn-outline" style="justify-content:center" onclick="ncPrintInvoice()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          Print / Save PDF
        </button>
      </div>
    </div>
  </div>

</div>
</div><!-- /#nc-detail-screen -->

</div><!-- /.nc-wrap -->
</div><!-- .wrap -->

<style>
/* ── Invoice: always in DOM, hidden on screen, visible on print ── */
.nc-invoice {
  /* Hidden on screen using position/clip, NOT display:none                */
  /* This lets @media print show it without the display:none battle        */
  position: absolute;
  left: -99999px;
  top: 0;
  width: 210mm; /* A4 width */
  background: #fff;
  font-family: 'Inter', sans-serif;
  padding: 32px;
  box-sizing: border-box;
  pointer-events: none;
}

/* ── Invoice internal styles ─────────────────────── */
.nc-inv-header { display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid #1d3461; }
.nc-inv-meta { display:flex; gap:32px; margin-bottom:24px; }
.nc-inv-meta-col { flex:1; }
.nc-inv-block-title { font-size:10px; font-weight:700; color:#667085; text-transform:uppercase; letter-spacing:.6px; margin-bottom:8px; }
.nc-inv-details-tbl { width:100%; font-size:12px; border-collapse:collapse; }
.nc-inv-details-tbl td { padding:3px 0; color:#344054; }
.nc-inv-details-tbl td:first-child { color:#667085; padding-right:12px; white-space:nowrap; }
.nc-inv-items { width:100%; border-collapse:collapse; font-size:13px; }
.nc-inv-items thead tr { background:#f6f7f9; border-bottom:2px solid #1d3461; }
.nc-inv-items th { padding:9px 12px; text-align:left; font-size:11px; font-weight:700; color:#667085; text-transform:uppercase; letter-spacing:.5px; }
.nc-inv-items td { padding:10px 12px; border-bottom:1px solid #e4e7ec; }
.nc-inv-items tbody tr:last-child td { border-bottom:none; }
.nc-inv-subtotal td { padding:7px 12px; border-top:1px solid #e4e7ec; color:#344054; font-size:13px; }
.nc-inv-total td { padding:10px 12px; border-top:2px solid #1d3461; }
.nc-inv-footer { text-align:center; font-size:11px; color:#98a2b3; padding-top:16px; margin-top:16px; border-top:1px solid #e4e7ec; }

/* ── Print: show ONLY the invoice ────────────────── */
@media print {
  /* Step 1: hide everything on screen */
  #wpadminbar,
  #adminmenumain,
  #adminmenuback,
  .nc-sidebar,
  #nc-screen-header,
  #nc-detail-screen { display: none !important; }

  /* Step 2: reset body & page */
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    background: #fff !important;
  }
  #wpwrap, #wpcontent, #wpbody, #wpbody-content,
  .wrap.nc-admin, .nc-wrap {
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    background: #fff !important;
    overflow: visible !important;
  }

  /* Step 3: bring invoice back into normal flow */
  .nc-invoice {
    position: static !important;
    left: auto !important;
    width: 100% !important;
    padding: 16px !important;
    pointer-events: auto !important;
  }

  /* Step 4: ensure invoice internals display correctly */
  .nc-inv-header { display: flex !important; }
  .nc-inv-meta   { display: flex !important; }

  /* Step 5: page setup */
  @page { margin: 12mm; size: A4; }
}
</style>

<script>
function ncPrintInvoice(){
  window.print();
}

jQuery(function($){
  var opts=$('#nc-status-opts');
  opts.on('change','input[type=radio]',function(){
    opts.find('.nc-sopt').removeClass('sel');
    $(this).closest('.nc-sopt').addClass('sel');
  });
  $('#nc-save-status').on('click',function(){
    var btn=$(this),oid=btn.data('order-id'),status=opts.find('input:checked').val();
    if(!status)return;
    btn.prop('disabled',true).html('<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Saving…');
    $.post(nc_admin.ajax_url,{action:'nc_update_order_status',nonce:nc_admin.nonce,order_id:oid,status:status},function(r){
      btn.prop('disabled',false).html('<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Save Status');
      var res=$('#nc-status-result');
      res.html(r.success?'<span style="color:var(--green);font-weight:600">✓ Updated!</span>':'<span style="color:var(--red)">Failed.</span>');
      setTimeout(function(){res.fadeOut(400,function(){res.html('').show();});},2500);
    });
  });
});
</script>
