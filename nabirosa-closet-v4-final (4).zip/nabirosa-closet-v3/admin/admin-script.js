(function($){
'use strict';

// ── Status save (orders list) ─────────────────────────────────
$(document).on('change', '.nc-status-select', function(){
  var sel = $(this), orderId = sel.data('order-id'), status = sel.val();
  $.post(nc_admin.ajax_url, {action:'nc_update_order_status',nonce:nc_admin.nonce,order_id:orderId,status:status}, function(r){
    if(r.success){
      var note = $('<span class="nc-saved-note">').html('<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg> Saved');
      var id = 'sn-'+orderId;
      sel.after(note.attr('id',id));
      setTimeout(function(){ $('#'+id).remove(); }, 2000);
    }
  });
});

// ── Range chips (analytics) ───────────────────────────────────
$(document).on('click', '.nc-chip[data-range]', function(){
  var el = $(this), range = el.data('range');
  el.closest('.nc-chips').find('.nc-chip').removeClass('active');
  el.addClass('active');
  $.post(nc_admin.ajax_url, {action:'nc_get_analytics',nonce:nc_admin.nonce,range:range}, function(r){
    if(r.success && window.ncUpdateCharts) window.ncUpdateCharts(r.data);
  });
});

// ── Export dropdown toggle ────────────────────────────────────
$(document).on('click', '.nc-export-toggle', function(e){
  e.stopPropagation();
  $(this).closest('.nc-export-wrap').toggleClass('open');
});
$(document).on('click', function(){ $('.nc-export-wrap').removeClass('open'); });

})(jQuery);
