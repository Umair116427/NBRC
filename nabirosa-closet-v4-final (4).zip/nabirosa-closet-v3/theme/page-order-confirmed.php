<?php
/**
 * Template Name: page-order-confirmed.php
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
</head>
<body>
<?php get_template_part('template-parts/navbar'); ?>

<section style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:4rem 5%;">
    <div class="order-confirmed" style="display:flex;flex-direction:column;align-items:center;text-align:center;max-width:480px;">
        <div class="confirmed-icon"><i class="fas fa-check-circle" style="font-size:4rem;color:var(--champagne-gold);"></i></div>
        <h2 style="margin:1rem 0 .5rem;font-size:2rem;">Order Placed!</h2>
        <?php
        $order_number = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : '';
        if ($order_number): ?>
        <p style="color:var(--deep-royal-blue);font-weight:600;font-size:1.1rem;">Order #<?php echo esc_html($order_number); ?></p>
        <?php endif; ?>
        <p style="color:#777;margin:.5rem 0 2rem;">Thank you for shopping with Nabirosa Closet. We'll contact you shortly to confirm delivery details.</p>
        <a href="<?php echo nc_url('home'); ?>" class="btn-primary" style="display:inline-block;">Back to Home</a>
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
</body>
</html>
