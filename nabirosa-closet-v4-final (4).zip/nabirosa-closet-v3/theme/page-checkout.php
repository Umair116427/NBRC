<?php
/**
 * Template Name: page-checkout.php
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
</head>
<body>
<?php get_template_part('template-parts/navbar'); ?>

<section class="checkout-page">
    <div class="checkout-inner">

        <div class="checkout-header">
            <h1>Checkout</h1>
            <p>Complete your order securely.</p>
        </div>

        <!-- Order Confirmed (shown after successful placement) -->
        <div id="order-confirmed" class="order-confirmed" style="display:none;">
            <div class="confirmed-icon"><i class="fas fa-check-circle"></i></div>
            <h2>Order Placed!</h2>
            <p id="order-confirmed-number"></p>
            <p>Thank you for shopping with Nabirosa Closet. We'll be in touch soon.</p>
            <a href="<?php echo nc_url('home'); ?>" class="btn-primary" style="margin-top:2rem;display:inline-block;">Back to Home</a>
        </div>

        <div class="checkout-layout" id="checkout-form-layout">

            <!-- Checkout Form Column -->
            <div class="checkout-form-col">
                <!-- Progress Steps -->
                <div class="checkout-steps">
                    <div class="step active" id="step-indicator-1">
                        <span class="step-num">1</span>
                        <span class="step-label">Delivery</span>
                    </div>
                    <div class="step-line"></div>
                    <div class="step" id="step-indicator-2">
                        <span class="step-num">2</span>
                        <span class="step-label">Payment</span>
                    </div>
                    <div class="step-line"></div>
                    <div class="step" id="step-indicator-3">
                        <span class="step-num">3</span>
                        <span class="step-label">Confirm</span>
                    </div>
                </div>

                <!-- Step 1: Delivery -->
                <div class="form-step" id="form-step-1">
                    <h3 class="form-section-title"><i class="fas fa-map-marker-alt"></i> Delivery Information</h3>
                    <form id="delivery-form" novalidate>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="first-name">First Name *</label>
                                <input type="text" id="first-name" placeholder="e.g. Aisha" required>
                            </div>
                            <div class="form-group">
                                <label for="last-name">Last Name *</label>
                                <input type="text" id="last-name" placeholder="e.g. Khan" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" id="phone" placeholder="03XX-XXXXXXX" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" placeholder="you@example.com">
                            </div>
                        </div>
                        <div class="form-group full-width">
                            <label for="address">Street Address *</label>
                            <input type="text" id="address" placeholder="House no., Street, Area" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="city">City *</label>
                                <input type="text" id="city" placeholder="e.g. Lahore" required>
                            </div>
                            <div class="form-group">
                                <label for="postal">Postal Code</label>
                                <input type="text" id="postal" placeholder="e.g. 54000">
                            </div>
                        </div>
                        <div class="form-group full-width">
                            <label for="notes">Order Notes (optional)</label>
                            <textarea id="notes" rows="3" placeholder="Any special instructions for your order..."></textarea>
                        </div>
                        <button type="button" class="btn-next" id="go-to-step-2">
                            Continue to Payment <i class="fas fa-arrow-right"></i>
                        </button>
                    </form>
                </div>

                <!-- Step 2: Payment -->
                <div class="form-step" id="form-step-2" style="display:none;">
                    <h3 class="form-section-title"><i class="fas fa-credit-card"></i> Payment Method</h3>
                    <div class="payment-options">
                        <label class="payment-option selected" id="cod-option">
                            <input type="radio" name="payment" value="cod" checked>
                            <div class="payment-option-content">
                                <i class="fas fa-money-bill-wave"></i>
                                <div><strong>Cash on Delivery</strong><small>Pay when you receive your order</small></div>
                            </div>
                        </label>
                        <label class="payment-option" id="bank-option">
                            <input type="radio" name="payment" value="bank">
                            <div class="payment-option-content">
                                <i class="fas fa-university"></i>
                                <div><strong>Bank Transfer</strong><small>Transfer to our account</small></div>
                            </div>
                        </label>
                        <label class="payment-option" id="jazz-option">
                            <input type="radio" name="payment" value="jazzcash">
                            <div class="payment-option-content">
                                <i class="fas fa-mobile-alt"></i>
                                <div><strong>JazzCash / EasyPaisa</strong><small>Mobile wallet payment</small></div>
                            </div>
                        </label>
                    </div>
                    <div id="bank-details" class="bank-details" style="display:none;">
                        <p><strong>Account Title:</strong> Nabirosa Closet</p>
                        <p><strong>Bank:</strong> HBL</p>
                        <p><strong>Account No:</strong> 0123-4567890-001</p>
                        <p class="bank-note"><i class="fas fa-info-circle"></i> Please send screenshot of receipt to our WhatsApp after placing order.</p>
                    </div>
                    <div class="step-nav">
                        <button type="button" class="btn-back" id="back-to-step-1"><i class="fas fa-arrow-left"></i> Back</button>
                        <button type="button" class="btn-next" id="go-to-step-3">Review Order <i class="fas fa-arrow-right"></i></button>
                    </div>
                </div>

                <!-- Step 3: Confirm -->
                <div class="form-step" id="form-step-3" style="display:none;">
                    <h3 class="form-section-title"><i class="fas fa-clipboard-check"></i> Review &amp; Confirm</h3>
                    <div class="review-section">
                        <div class="review-group">
                            <h4>Delivering to:</h4>
                            <div id="review-delivery" class="review-content"></div>
                        </div>
                        <div class="review-group">
                            <h4>Payment Method:</h4>
                            <div id="review-payment" class="review-content"></div>
                        </div>
                    </div>
                    <div class="review-group">
                        <h4>Items Ordered:</h4>
                        <div id="review-items" class="review-items-list"></div>
                    </div>
                    <div class="review-total-row">
                        <span>Grand Total:</span>
                        <span id="review-total" class="review-grand-total">PKR 0</span>
                    </div>
                    <div class="step-nav">
                        <button type="button" class="btn-back" id="back-to-step-2"><i class="fas fa-arrow-left"></i> Back</button>
                        <button type="button" class="btn-place-order" id="place-order-btn">
                            <i class="fas fa-check"></i> Place Order
                        </button>
                    </div>
                </div>
            </div>

            <!-- Order Summary Sidebar -->
            <div class="checkout-summary-col">
                <div class="summary-card">
                    <h3>Your Bag</h3>
                    <div id="checkout-items-preview"></div>
                    <div class="summary-divider"></div>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span id="co-subtotal">PKR 0</span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span>PKR 200</span>
                    </div>
                    <div class="summary-divider"></div>
                    <div class="summary-row summary-total">
                        <span>Total</span>
                        <span id="co-total">PKR 0</span>
                    </div>
                    <div class="secure-badges">
                        <span><i class="fas fa-shield-alt"></i> Secure</span>
                        <span><i class="fas fa-undo"></i> Easy Returns</span>
                    </div>
                </div>
            </div>

        </div><!-- /#checkout-form-layout -->
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
</body>
</html>
