<footer class="footer">
    <div class="footer-content">
        <div class="footer-brand">
            <span class="footer-brand-name">Nabirosa Closet</span>
            <p>Handcrafted with love. Every stitch tells a story of tradition, skill, and timeless elegance.</p>
            <div class="social-links" style="margin-top:1.2rem;">
                <a href="https://www.instagram.com/simply_nabila7?igsh=MXV5dW9tdDY4eW16Yg==" target="_blank" rel="noopener" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://www.youtube.com/@simply_nabila7?si=QU5NE-ZdY03VNZ27" target="_blank" rel="noopener" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
                <a href="https://www.tiktok.com/@simply_nabila7?_r=1&_t=ZS-94KOquhI9zB" target="_blank" rel="noopener" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <h4>Explore</h4>
            <ul>
                <li><a href="<?php echo nc_url('shop'); ?>">Shop Collection</a></li>
                <li><a href="<?php echo nc_url('arrivals'); ?>">New Arrivals</a></li>
                <li><a href="<?php echo nc_url('about'); ?>">Our Story</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Customer Care</h4>
            <ul>
                <li><a href="#" class="policy-link" data-section="contact">Contact Us</a></li>
                <li><a href="#" class="policy-link" data-section="shipping">Shipping Info</a></li>
                <li><a href="#" class="policy-link" data-section="returns">Returns</a></li>
                <li><a href="#" class="policy-link" data-section="faq">FAQs</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4>Policies</h4>
            <ul>
                <li><a href="#" class="policy-link" data-section="privacy">Privacy Policy</a></li>
                <li><a href="#" class="policy-link" data-section="terms">Terms of Service</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> Nabirosa Closet. All Rights Reserved.</p>
        <p>Made with <i class="fas fa-heart" style="color:var(--champagne-gold);"></i> in Pakistan</p>
    </div>
</footer>

<!-- Policy Popup Modal -->
<div class="policy-overlay" id="policyOverlay">
    <div class="policy-modal">
        <button class="policy-close" id="policyClose"><i class="fas fa-times"></i></button>
        <div class="policy-modal-inner">
            <div class="policy-logo">Nabirosa Closet</div>
            <div class="policy-section" id="policy-returns">
                <h2><i class="fas fa-undo-alt"></i> Returns &amp; Refunds Policy</h2>
                <p class="policy-eff">Effective Date: 1 March 2026</p>
                <p>At Nabirosa Closet, we believe shopping should feel effortless and confident.</p>
                <h3>1. Eligibility</h3>
                <ul><li>Item must be unused, unwashed, and in original packaging.</li><li>Tags must remain attached.</li><li>Return request within <strong>7 days</strong> of delivery.</li></ul>
                <h3>2. Damaged or Incorrect Items</h3>
                <ul><li>Email within <strong>48 hours</strong> of delivery.</li><li>Replacement OR full refund.</li></ul>
                <h3>3. Non-Returnable Items</h3>
                <ul><li>Customized products</li><li>Clearance items</li><li>Worn or washed items</li></ul>
            </div>
            <div class="policy-section" id="policy-shipping">
                <h2><i class="fas fa-truck"></i> Shipping Information</h2>
                <div class="policy-table">
                    <div class="policy-row"><span>Standard Shipping</span><span>8–9 business days — PKR 300</span></div>
                    <div class="policy-row"><span>Express Shipping</span><span>4–5 business days — PKR 600</span></div>
                    <div class="policy-row"><span>Cash on Delivery</span><span>Available in selected areas</span></div>
                    <div class="policy-row"><span>International Shipping</span><span>Currently unavailable</span></div>
                </div>
            </div>
            <div class="policy-section" id="policy-privacy">
                <h2><i class="fas fa-shield-alt"></i> Privacy Policy</h2>
                <p class="policy-eff">Last Updated: 1 March 2026</p>
                <h3>Information We Collect</h3>
                <ul><li>Name, Email, Phone, Address</li><li>Payment transaction details</li></ul>
                <div class="policy-highlight"><i class="fas fa-lock"></i> We do <strong>NOT</strong> sell personal data.</div>
            </div>
            <div class="policy-section" id="policy-terms">
                <h2><i class="fas fa-file-contract"></i> Terms of Service</h2>
                <p class="policy-eff">Effective Date: 1 March 2026</p>
                <h3>1. Pricing</h3>
                <ul><li>All prices are in PKR and subject to change.</li><li>Payment required before processing (except COD).</li></ul>
                <h3>2. Governing Law</h3>
                <p>Governed by the laws of Pakistan.</p>
            </div>
            <div class="policy-section" id="policy-contact">
                <h2><i class="fas fa-envelope"></i> Contact Us</h2>
                <div class="policy-table">
                    <div class="policy-row"><span>Address</span><span>Purana Kahna Nau, Lahore, Pakistan</span></div>
                    <div class="policy-row"><span>Response Time</span><span>24–48 business hours</span></div>
                </div>
                <div class="policy-socials">
                    <a href="https://www.instagram.com/simply_nabila7" target="_blank" rel="noopener"><i class="fab fa-instagram"></i> Instagram</a>
                    <a href="https://www.tiktok.com/@simply_nabila7" target="_blank" rel="noopener"><i class="fab fa-tiktok"></i> TikTok</a>
                </div>
            </div>
            <div class="policy-section" id="policy-faq">
                <h2><i class="fas fa-question-circle"></i> FAQs</h2>
                <div class="policy-faq-item"><div class="policy-faq-q">How long does delivery take?</div><div class="policy-faq-a">Standard: 8–9 days. Express: 4–5 days.</div></div>
                <div class="policy-faq-item"><div class="policy-faq-q">Can I return my order?</div><div class="policy-faq-a">Yes, within 7 days if unused and in original condition.</div></div>
                <div class="policy-faq-item"><div class="policy-faq-q">Do you offer Cash on Delivery?</div><div class="policy-faq-a">Yes, in selected areas.</div></div>
            </div>
        </div>
    </div>
</div>

<?php wp_footer(); ?>
