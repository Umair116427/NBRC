<?php
/**
 * Product card partial
 * $product = stdClass from NC_Products::get_all()
 */
if ( ! isset( $product ) ) return;

$discount = '';
if ( $product->orig_price && $product->price < $product->orig_price ) {
    $discount = round( ( 1 - $product->price / $product->orig_price ) * 100 ) . '% Off';
}
$meta_tags = array_filter( explode( ',', $product->meta_tags ) );
?>
<div class="shop-card quick-view-trigger"
     data-id="<?php echo esc_attr($product->id); ?>"
     data-name="<?php echo esc_attr($product->name); ?>"
     data-price="<?php echo esc_attr($product->price); ?>"
     data-orig="<?php echo esc_attr($product->orig_price ?? ''); ?>"
     data-discount="<?php echo esc_attr($discount); ?>"
     data-badge="<?php echo esc_attr($product->badge); ?>"
     data-desc="<?php echo esc_attr($product->description); ?>"
     data-image="<?php echo esc_attr($product->image_url); ?>"
     data-coming-soon="<?php echo $product->is_coming_soon ? '1' : '0'; ?>">
    <div class="shop-card-img">
        <img src="<?php echo esc_url($product->image_url); ?>"
             alt="<?php echo esc_attr($product->name); ?>"
             onerror="this.src='https://placehold.co/600x800/F3E8EA/243A73?text=Nabirosa+Closet'">
        <?php if ( $product->badge ): ?>
        <span class="shop-card-badge"
              <?php if ($product->is_coming_soon) echo 'style="background:var(--midnight-navy);"'; ?>>
            <?php echo esc_html($product->badge); ?>
        </span>
        <?php endif; ?>
    </div>
    <div class="shop-card-body">
        <h3 <?php if($product->is_coming_soon) echo 'style="color:#888;"'; ?>>
            <?php echo esc_html($product->name); ?>
        </h3>
        <div class="shop-card-prices">
            <?php if ( $product->orig_price ): ?>
            <span class="orig">PKR <?php echo number_format($product->orig_price, 0); ?></span>
            <?php endif; ?>
            <?php if ( ! $product->is_coming_soon ): ?>
            <span class="sale">PKR <?php echo number_format($product->price, 0); ?></span>
            <?php if ( $discount ): ?>
            <span class="pill"><?php echo esc_html($discount); ?></span>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if ( $product->is_coming_soon ): ?>
        <p style="font-size:0.85rem;color:#aaa;margin-bottom:1rem;">We are weaving something magical.</p>
        <button class="shop-add-btn" style="background:#ccc;color:#666;cursor:not-allowed;" disabled>
            <i class="fas fa-lock"></i> Stay Tuned
        </button>
        <?php else: ?>
        <button class="shop-add-btn add-to-cart-btn"
                data-id="<?php echo esc_attr($product->id); ?>"
                data-name="<?php echo esc_attr($product->name); ?>"
                data-price="<?php echo esc_attr($product->price); ?>"
                data-image="<?php echo esc_attr($product->image_url); ?>">
            <i class="fas fa-shopping-bag"></i> Add to Bag
        </button>
        <?php endif; ?>
    </div>
</div>
