<!-- Navbar -->
<nav class="navbar">
    <div class="logo">
        <a href="<?php echo nc_url('home'); ?>">
            <img src="https://raw.githubusercontent.com/Umair116427/NBRC/refs/heads/main/Pastel_Purple_Retro_Bold_Cafe_Logo-removebg-preview__2_-removebg-preview.png" alt="Nabirosa Closet Logo">
        </a>
    </div>
    <ul class="nav-links">
        <li><a href="<?php echo nc_url('home'); ?>" <?php echo nc_active('home'); ?>>Home</a></li>
        <li><a href="<?php echo nc_url('shop'); ?>" <?php echo nc_active('shop'); ?>>Shop Collection</a></li>
        <li><a href="<?php echo nc_url('arrivals'); ?>" <?php echo nc_active('arrivals'); ?>>New Arrivals</a></li>
        <li><a href="<?php echo nc_url('about'); ?>" <?php echo nc_active('about'); ?>>About Us</a></li>
    </ul>
    <div class="nav-icons">
        <i class="fas fa-search"></i>
        <i class="fas fa-user"></i>
        <a href="<?php echo nc_url('cart'); ?>" class="cart-icon">
            <i class="fas fa-shopping-bag"></i>
            <span class="cart-count">0</span>
        </a>
    </div>
    <div class="hamburger"><i class="fas fa-bars"></i></div>
</nav>

<!-- Search Overlay -->
<div class="search-overlay" id="searchOverlay">
    <button class="search-close" id="searchClose"><i class="fas fa-times"></i></button>
    <div class="search-box">
        <i class="fas fa-search" style="color:#aaa;font-size:1.1rem;"></i>
        <input type="text" id="searchInput" placeholder="Search for handmade pieces…" autocomplete="off">
        <button class="search-submit"><i class="fas fa-arrow-right"></i></button>
    </div>
</div>

<!-- Mobile Bottom Navigation -->
<nav class="mobile-bottom-nav">
    <a href="<?php echo nc_url('home'); ?>" <?php echo nc_bottom_active('home'); ?>>
        <i class="fas fa-home"></i><span>Home</span>
    </a>
    <a href="<?php echo nc_url('shop'); ?>" <?php echo nc_bottom_active('shop'); ?>>
        <i class="fas fa-store"></i><span>Shop</span>
    </a>
    <a href="<?php echo nc_url('arrivals'); ?>" <?php echo nc_bottom_active('arrivals'); ?>>
        <i class="fas fa-star"></i><span>New</span>
    </a>
    <a href="<?php echo nc_url('cart'); ?>" <?php echo nc_bottom_active('cart'); ?>>
        <i class="fas fa-shopping-bag"></i><span>Cart</span>
        <span class="mobile-cart-count bottom-nav-cart-badge"></span>
    </a>
    <a href="<?php echo nc_url('about'); ?>" <?php echo nc_bottom_active('about'); ?>>
        <i class="fas fa-heart"></i><span>About</span>
    </a>
</nav>
