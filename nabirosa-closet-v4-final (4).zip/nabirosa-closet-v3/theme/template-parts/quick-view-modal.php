<!-- Quick View Modal -->
<div class="quick-view-overlay" id="quickViewOverlay">
    <div class="quick-view-modal">
        <button class="quick-view-close" id="quickViewClose"><i class="fas fa-times"></i></button>
        <div class="quick-view-content">
            <div class="quick-view-img-col">
                <img src="" alt="Product Image" id="qvImage">
                <span class="sale-badge" id="qvBadge"></span>
            </div>
            <div class="quick-view-details-col">
                <h2 id="qvTitle">Product Title</h2>
                <div class="price-container">
                    <span class="original-price" id="qvOrigPrice"></span>
                    <span class="sale-price" id="qvSalePrice">PKR 0</span>
                    <span class="discount-pill" id="qvDiscount"></span>
                </div>
                <div class="product-meta" id="qvMeta"></div>
                <p class="product-desc" id="qvDesc">Description goes here.</p>
                <div class="qv-actions">
                    <div class="qty-selector">
                        <button id="qvMinus"><i class="fas fa-minus"></i></button>
                        <input type="number" id="qvQty" value="1" min="1" readonly>
                        <button id="qvPlus"><i class="fas fa-plus"></i></button>
                    </div>
                    <button class="add-to-cart-btn" id="qvAddBtn">
                        <i class="fas fa-shopping-bag"></i> Add to Bag
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
