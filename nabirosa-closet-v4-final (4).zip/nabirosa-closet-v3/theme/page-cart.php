<?php
/**
 * Template Name: page-cart.php
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
</head>
<body>
<?php get_template_part('template-parts/navbar'); ?>

<section class="cart-page">
    <div class="cart-page-inner">
        <div class="cart-page-header">
            <h1>Your Shopping Bag</h1>
            <p class="cart-subtitle">Review your items before checkout.</p>
        </div>
        <div class="cart-layout">
            <div class="cart-items-col">
                <div id="cart-items-container"></div>
                <div id="empty-cart" class="empty-cart" style="display:none;">
                    <div class="empty-cart-icon"><i class="fas fa-shopping-bag"></i></div>
                    <h3>Your bag is empty</h3>
                    <p>Looks like you haven't added anything yet.</p>
                    <a href="<?php echo nc_url('shop'); ?>" class="btn-primary" style="margin-top:1.5rem;display:inline-block;">Explore Collection</a>
                </div>
            </div>
            <div class="cart-summary-col" id="cart-summary">
                <div class="summary-card">
                    <h3>Order Summary</h3>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span id="cart-subtotal">PKR 0</span>
                    </div>
                    <div class="summary-row">
                        <span>Shipping</span>
                        <span id="cart-shipping">PKR 200</span>
                    </div>
                    <div class="summary-divider"></div>
                    <div class="summary-row summary-total">
                        <span>Total</span>
                        <span id="cart-total">PKR 200</span>
                    </div>
                    <a href="<?php echo nc_url('checkout'); ?>" id="checkout-btn" class="checkout-btn">
                        <i class="fas fa-lock"></i> Proceed to Checkout
                    </a>
                    <a href="<?php echo nc_url('shop'); ?>" class="continue-shopping">
                        <i class="fas fa-arrow-left"></i> Continue Shopping
                    </a>
                    <div class="secure-badges">
                        <span><i class="fas fa-shield-alt"></i> Secure Checkout</span>
                        <span><i class="fas fa-undo"></i> Easy Returns</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
</body>
</html>
