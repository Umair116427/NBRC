<?php
/**
 * Template Name: page-about.php
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Learn the story behind Nabirosa Closet — passion, artisanship, and timeless handmade fashion.">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
    <style>
        .about-banner{background:linear-gradient(145deg,var(--soft-rose-nude) 0%,#f7e8eb 100%);padding:6rem 5% 5rem;text-align:center;position:relative;overflow:hidden}
        .about-banner::before{content:'';position:absolute;width:350px;height:350px;background:rgba(203,182,227,.3);border-radius:50%;top:-100px;right:-80px;pointer-events:none}
        .about-banner .banner-eyebrow{display:inline-block;font-size:.75rem;font-weight:600;letter-spacing:3px;text-transform:uppercase;color:var(--deep-royal-blue);background:rgba(36,58,115,.08);padding:.35rem 1rem;border-radius:50px;margin-bottom:1rem;position:relative;z-index:2}
        .about-banner h1{font-size:3rem;color:var(--midnight-navy);margin-bottom:.5rem;position:relative;z-index:2}
        .about-banner p{color:#888;font-style:italic;position:relative;z-index:2}
        .banner-divider{width:40px;height:3px;background:linear-gradient(90deg,var(--champagne-gold),var(--primary-lavender));border-radius:3px;margin:.8rem auto 0;position:relative;z-index:2}
        .about-section{padding:5rem 5%;background:var(--neutral-white)}
        .about-inner{max-width:860px;margin:0 auto}
        .about-lead{font-family:var(--font-secondary);font-size:1.5rem;color:var(--midnight-navy);line-height:1.6;margin-bottom:2rem;font-style:italic}
        .about-body{color:#555;font-size:1.05rem;line-height:1.9;margin-bottom:1.6rem}
        .values-section{padding:5rem 5%;background:var(--neutral-grey)}
        .values-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;max-width:1000px;margin:0 auto}
        .value-card{background:var(--neutral-white);border-radius:var(--radius-card);padding:2.5rem 2rem;text-align:center;box-shadow:var(--shadow-md);transition:transform var(--transition),box-shadow var(--transition)}
        .value-card:hover{transform:translateY(-6px);box-shadow:var(--shadow-lg)}
        .value-icon{width:60px;height:60px;background:linear-gradient(135deg,var(--primary-lavender),#e8d5f5);border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 1.2rem;font-size:1.4rem;color:var(--deep-royal-blue)}
        .value-card h3{font-size:1.1rem;color:var(--midnight-navy);margin-bottom:.5rem}
        .value-card p{font-size:.9rem;color:#888;line-height:1.7}
        @media(max-width:768px){.about-banner h1{font-size:2.2rem}.about-lead{font-size:1.2rem}.values-grid{grid-template-columns:1fr 1fr}}
        @media(max-width:480px){.about-banner h1{font-size:1.8rem}.about-lead{font-size:1.05rem}.values-grid{grid-template-columns:1fr}.about-banner{padding:4rem 5% 3rem}}
    </style>
</head>
<body>
<?php get_template_part('template-parts/navbar'); ?>

<div class="about-banner">
    <span class="banner-eyebrow">The Person Behind the Pieces</span>
    <h1>About Me</h1>
    <p>A dream stitched with care.</p>
    <div class="banner-divider"></div>
</div>

<section class="about-section">
    <div class="about-inner">
        <p class="about-lead">"It's not just a store — it's a dream stitched with care."</p>
        <p class="about-body">I design thoughtfully crafted, elegant pieces that blend modern style with comfort and quality. Every item is created with attention to detail and a passion for timeless fashion you can trust.</p>
    </div>
</section>

<section class="values-section">
    <div class="section-header" style="margin-bottom:3rem;">
        <h2>What We Stand For</h2>
        <p>The principles that guide every stitch we make.</p>
        <div class="section-divider"></div>
    </div>
    <div class="values-grid">
        <div class="value-card">
            <div class="value-icon"><i class="fas fa-hands"></i></div>
            <h3>Handcrafted Quality</h3>
            <p>Every piece is made by hand, ensuring no two items are exactly alike — a mark of true artistry.</p>
        </div>
        <div class="value-card">
            <div class="value-icon"><i class="fas fa-leaf"></i></div>
            <h3>Sustainable Fashion</h3>
            <p>We prioritise quality over quantity, creating pieces that stand the test of time.</p>
        </div>
        <div class="value-card">
            <div class="value-icon"><i class="fas fa-heart"></i></div>
            <h3>Made with Love</h3>
            <p>Passion drives every decision we make — from fabric selection to the final stitch.</p>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
</body>
</html>
