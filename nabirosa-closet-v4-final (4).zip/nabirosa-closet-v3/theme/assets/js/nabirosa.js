// ============================================================
//  Nabirosa Closet – Main Script (WordPress Edition)
//  Cart uses localStorage. Orders submitted via REST API.
// ============================================================

if (typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
}

// ── REST API Config (injected via wp_localize_script) ────────
var ncRest     = (typeof nc_data !== 'undefined') ? nc_data.rest_url   : '/wp-json/nabirosa/v1/';
var ncNonce    = (typeof nc_data !== 'undefined') ? nc_data.nonce      : '';
var ncCartUrl  = (typeof nc_data !== 'undefined') ? nc_data.cart_url   : '/cart/';
var ncCheckUrl = (typeof nc_data !== 'undefined') ? nc_data.checkout_url : '/checkout/';
var ncConfUrl  = (typeof nc_data !== 'undefined') ? nc_data.confirmed_url : '/order-confirmed/';
var ncShopUrl  = (typeof nc_data !== 'undefined') ? nc_data.shop_url   : '/shop/';
var ncHomeUrl  = (typeof nc_data !== 'undefined') ? nc_data.home_url   : '/';

// ── Cart State ───────────────────────────────────────────────
let cart = [];
try { cart = JSON.parse(localStorage.getItem('nc_cart')) || []; } catch(e) { cart = []; }

function saveCart() {
    localStorage.setItem('nc_cart', JSON.stringify(cart));
}

function getCartTotalQty() {
    return cart.reduce((sum, i) => sum + i.qty, 0);
}

function getSubtotal() {
    return cart.reduce((sum, i) => sum + i.price * i.qty, 0);
}

function updateCartBadge() {
    document.querySelectorAll('.cart-count, .mobile-cart-count, .bottom-nav-cart-badge').forEach(el => {
        const qty = getCartTotalQty();
        el.textContent = qty;
        el.style.display = qty === 0 ? 'none' : 'flex';
    });
}

// ── Add to Cart ──────────────────────────────────────────────
function addToCart(product) {
    const existing = cart.find(i => i.id === product.id);
    if (existing) {
        existing.qty += (product.qty || 1);
    } else {
        cart.push({ ...product, qty: product.qty || 1 });
    }
    saveCart();
    updateCartBadge();
    showToast('<i class="fas fa-check-circle"></i> Added to bag!');
}

function showToast(html) {
    let toast = document.getElementById('nc-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'nc-toast';
        toast.className = 'nc-toast';
        document.body.appendChild(toast);
    }
    toast.innerHTML = html;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

// ── DOMContentLoaded ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

    updateCartBadge();

    // ── Navbar Scroll Effect ─────────────────────────────
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 40) {
                navbar.classList.add('scrolled');
                navbar.style.boxShadow = '0 8px 30px rgba(0,0,0,0.10)';
            } else {
                navbar.classList.remove('scrolled');
                navbar.style.boxShadow = '';
            }
        });
    }

    // ── Search Overlay ───────────────────────────────────
    const searchOverlay = document.getElementById('searchOverlay');
    const searchClose   = document.getElementById('searchClose');
    const searchInput   = document.getElementById('searchInput');
    const searchIcon    = document.querySelector('.nav-icons .fa-search');

    if (searchIcon && searchOverlay) {
        searchIcon.addEventListener('click', () => {
            searchOverlay.classList.add('active');
            setTimeout(() => searchInput && searchInput.focus(), 100);
        });
    }
    if (searchClose) searchClose.addEventListener('click', () => searchOverlay.classList.remove('active'));
    if (searchOverlay) searchOverlay.addEventListener('click', (e) => {
        if (e.target === searchOverlay) searchOverlay.classList.remove('active');
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchOverlay) searchOverlay.classList.remove('active');
    });

    // ── Loading Screen ───────────────────────────────────
    const loader = document.querySelector('.loader');
    if (loader) {
        const tl = gsap.timeline();
        tl.to('.loader-text',  { opacity: 1, duration: 1, y: -20, ease: 'power2.out' })
          .to('.loader-bar',   { width: '200px', duration: 2, ease: 'power1.inOut' }, '-=0.5')
          .to('.loader',       { y: '-100%', duration: 1, ease: 'power4.inOut', delay: 0.5 })
          .from('.navbar',     { y: -100, opacity: 0, duration: 0.8, ease: 'power2.out' })
          .to('.hero-content', { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }, '-=0.4');

        if (typeof ScrollTrigger !== 'undefined') {
            gsap.from('.product-card', {
                scrollTrigger: { trigger: '.featured', start: 'top 80%', toggleActions: 'play none none reverse' },
                y: 50, opacity: 0, duration: 1, ease: 'power2.out'
            });
        }
    }

    // ── Shop card animations ─────────────────────────────
    const shopCards = document.querySelectorAll('.shop-card');
    if (shopCards.length) {
        gsap.from(shopCards, { y: 40, opacity: 0, duration: 0.7, stagger: 0.15, ease: 'power2.out', delay: 0.2 });
    }

    // ── Add to Cart Buttons ──────────────────────────────
    // Handles both featured (index) cards and shop cards
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        if (btn.id === 'qvAddBtn') return; // handled separately
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const id    = btn.dataset.id    || btn.closest('[data-id]')?.dataset.id    || 'product-001';
            const name  = btn.dataset.name  || btn.closest('[data-name]')?.dataset.name  || 'Handmade Piece';
            const price = parseFloat(btn.dataset.price || btn.closest('[data-price]')?.dataset.price || 0);
            const image = btn.dataset.image || btn.closest('[data-image]')?.dataset.image || '';
            addToCart({ id, name, price, image });
            btn.innerHTML = '✓ Added!';
            btn.style.backgroundColor = 'var(--champagne-gold)';
            btn.style.color = 'var(--midnight-navy)';
            setTimeout(() => {
                btn.innerHTML = '<i class="fas fa-shopping-bag"></i> Add to Bag';
                btn.style.backgroundColor = '';
                btn.style.color = '';
            }, 1500);
        });
    });

    // ── Quick View Modal ─────────────────────────────────
    const qvOverlay  = document.getElementById('quickViewOverlay');
    const qvClose    = document.getElementById('quickViewClose');
    const qvAddBtn   = document.getElementById('qvAddBtn');
    const qvMinus    = document.getElementById('qvMinus');
    const qvPlus     = document.getElementById('qvPlus');
    const qvQtyInput = document.getElementById('qvQty');
    let currentQvProduct = null;

    if (qvMinus && qvQtyInput) {
        qvMinus.addEventListener('click', () => {
            let v = parseInt(qvQtyInput.value); if (v > 1) qvQtyInput.value = v - 1;
        });
    }
    if (qvPlus && qvQtyInput) {
        qvPlus.addEventListener('click', () => {
            qvQtyInput.value = parseInt(qvQtyInput.value) + 1;
        });
    }

    function closeQuickView() {
        if (qvOverlay) qvOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }
    if (qvClose) qvClose.addEventListener('click', closeQuickView);
    if (qvOverlay) qvOverlay.addEventListener('click', (e) => { if (e.target === qvOverlay) closeQuickView(); });

    document.querySelectorAll('.quick-view-trigger').forEach(card => {
        card.addEventListener('click', (e) => {
            if (e.target.closest('.add-to-cart-btn') || e.target.closest('.shop-add-btn')) return;

            // Read from data attributes (set in PHP templates)
            const id          = card.dataset.id;
            const name        = card.dataset.name;
            const price       = parseFloat(card.dataset.price || 0);
            const orig        = card.dataset.orig;
            const discount    = card.dataset.discount;
            const badge       = card.dataset.badge;
            const desc        = card.dataset.desc;
            const image       = card.dataset.image;
            const isComingSoon= card.dataset.comingSoon === '1';

            // Fallback: try reading from DOM if data attrs missing
            const imgEl       = card.querySelector('img');
            const imgSrc      = image || (imgEl ? imgEl.src : '');

            document.getElementById('qvImage').src               = imgSrc;
            document.getElementById('qvTitle').textContent       = name || card.querySelector('h3')?.textContent || '';
            document.getElementById('qvDesc').textContent        = desc || '';
            document.getElementById('qvSalePrice').textContent   = price ? 'PKR ' + price.toLocaleString() : '';
            document.getElementById('qvOrigPrice').textContent   = orig ? 'PKR ' + parseFloat(orig).toLocaleString() : '';
            document.getElementById('qvOrigPrice').style.display = orig ? 'inline' : 'none';
            document.getElementById('qvDiscount').textContent    = discount || '';
            document.getElementById('qvDiscount').style.display  = discount ? 'inline-block' : 'none';

            const qvBadge = document.getElementById('qvBadge');
            if (badge) { qvBadge.textContent = badge; qvBadge.style.display = 'block'; }
            else        { qvBadge.style.display = 'none'; }

            document.getElementById('qvMeta').style.display = 'none';

            if (qvQtyInput) qvQtyInput.value = 1;

            if (isComingSoon) {
                qvAddBtn.disabled = true;
                qvAddBtn.style.cssText = 'background:#ccc;color:#666;cursor:not-allowed;';
                qvAddBtn.innerHTML = '<i class="fas fa-lock"></i> Stay Tuned';
                if (qvQtyInput) qvQtyInput.disabled = true;
            } else {
                qvAddBtn.disabled = false;
                qvAddBtn.style.cssText = '';
                qvAddBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> Add to Bag';
                if (qvQtyInput) qvQtyInput.disabled = false;
                currentQvProduct = { id, name, price, image: imgSrc };
            }

            qvOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });

    if (qvAddBtn) {
        qvAddBtn.addEventListener('click', () => {
            if (!currentQvProduct || qvAddBtn.disabled) return;
            const qty = parseInt(qvQtyInput?.value) || 1;
            addToCart({ ...currentQvProduct, qty });
            qvAddBtn.textContent = '✓ Added!';
            qvAddBtn.style.backgroundColor = 'var(--champagne-gold)';
            qvAddBtn.style.color = 'var(--midnight-navy)';
            setTimeout(() => {
                qvAddBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> Add to Bag';
                qvAddBtn.style.backgroundColor = 'var(--midnight-navy)';
                qvAddBtn.style.color = '#fff';
            }, 1000);
        });
    }

    // ── Cart Page ────────────────────────────────────────
    if (document.getElementById('cart-items-container')) renderCart();

    // ── Checkout Page ────────────────────────────────────
    if (document.getElementById('checkout-form-layout')) initCheckout();

    // ── Policy Popup ─────────────────────────────────────
    const policyOverlay = document.getElementById('policyOverlay');
    const policyClose   = document.getElementById('policyClose');

    function openPolicy(section) {
        if (!policyOverlay) return;
        policyOverlay.querySelectorAll('.policy-section').forEach(s => s.style.display = 'none');
        const target = document.getElementById('policy-' + section);
        if (target) target.style.display = 'block';
        const inner = policyOverlay.querySelector('.policy-modal');
        if (inner) inner.scrollTop = 0;
        policyOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    function closePolicy() {
        if (!policyOverlay) return;
        policyOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.policy-link').forEach(link => {
        link.addEventListener('click', (e) => { e.preventDefault(); openPolicy(link.dataset.section); });
    });
    if (policyClose) policyClose.addEventListener('click', closePolicy);
    if (policyOverlay) policyOverlay.addEventListener('click', (e) => { if (e.target === policyOverlay) closePolicy(); });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && policyOverlay?.classList.contains('active')) closePolicy();
    });
});

// ============================================================
//  CART PAGE
// ============================================================
function renderCart() {
    const container = document.getElementById('cart-items-container');
    const emptyEl   = document.getElementById('empty-cart');
    const summaryEl = document.getElementById('cart-summary');
    if (!container) return;

    if (cart.length === 0) {
        container.innerHTML = '';
        if (emptyEl) emptyEl.style.display = 'flex';
        if (summaryEl) summaryEl.style.display = 'none';
        return;
    }

    if (emptyEl) emptyEl.style.display = 'none';
    if (summaryEl) summaryEl.style.display = 'block';

    container.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <div class="cart-item-img">
                <img src="${item.image || ''}" alt="${item.name}"
                     onerror="this.src='https://placehold.co/120x140/F3E8EA/243A73?text=Nabirosa'">
            </div>
            <div class="cart-item-details">
                <h4>${item.name}</h4>
                <p class="cart-item-price">PKR ${item.price.toLocaleString()}</p>
                <div class="qty-controls">
                    <button class="qty-btn" onclick="changeQty('${item.id}', -1)"><i class="fas fa-minus"></i></button>
                    <span class="qty-num">${item.qty}</span>
                    <button class="qty-btn" onclick="changeQty('${item.id}', 1)"><i class="fas fa-plus"></i></button>
                </div>
            </div>
            <div class="cart-item-right">
                <span class="cart-item-total">PKR ${(item.price * item.qty).toLocaleString()}</span>
                <button class="remove-item-btn" onclick="removeItem('${item.id}')"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>
    `).join('');

    updateSummary();
    gsap.from('.cart-item', { y: 20, opacity: 0, duration: 0.4, stagger: 0.1, ease: 'power2.out' });
}

function changeQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) cart = cart.filter(i => i.id !== id);
    saveCart();
    updateCartBadge();
    renderCart();
}

function removeItem(id) {
    const el = document.querySelector(`.cart-item[data-id="${id}"]`);
    if (el) {
        gsap.to(el, { opacity: 0, x: 30, duration: 0.3, ease: 'power2.in', onComplete: () => {
            cart = cart.filter(i => i.id !== id);
            saveCart();
            updateCartBadge();
            renderCart();
        }});
    }
}

function updateSummary() {
    const subtotal = getSubtotal();
    const shipping = subtotal > 0 ? 200 : 0;
    const total    = subtotal + shipping;
    const fmt = n => `PKR ${n.toLocaleString()}`;
    const el  = id  => document.getElementById(id);
    if (el('cart-subtotal')) el('cart-subtotal').textContent = fmt(subtotal);
    if (el('cart-shipping')) el('cart-shipping').textContent = fmt(shipping);
    if (el('cart-total'))    el('cart-total').textContent    = fmt(total);
}

// ============================================================
//  CHECKOUT PAGE
// ============================================================
function initCheckout() {
    renderCheckoutSidebar();

    document.getElementById('go-to-step-2')?.addEventListener('click', () => {
        if (validateDelivery()) goToStep(2);
    });
    document.getElementById('back-to-step-1')?.addEventListener('click', () => goToStep(1));
    document.getElementById('go-to-step-3')?.addEventListener('click', () => {
        buildReview();
        goToStep(3);
    });
    document.getElementById('back-to-step-2')?.addEventListener('click', () => goToStep(2));
    document.getElementById('place-order-btn')?.addEventListener('click', placeOrder);

    document.querySelectorAll('.payment-option input[type="radio"]').forEach(radio => {
        radio.addEventListener('change', () => {
            document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('selected'));
            radio.closest('.payment-option').classList.add('selected');
            const bankDetails = document.getElementById('bank-details');
            if (bankDetails) bankDetails.style.display = radio.value === 'bank' ? 'block' : 'none';
        });
    });
}

function renderCheckoutSidebar() {
    const preview   = document.getElementById('checkout-items-preview');
    const coSubtotal= document.getElementById('co-subtotal');
    const coTotal   = document.getElementById('co-total');
    if (!preview) return;

    const subtotal = getSubtotal();
    const total    = subtotal + 200;

    preview.innerHTML = cart.map(item => `
        <div class="co-item-row">
            <img src="${item.image || ''}" alt="${item.name}"
                 onerror="this.src='https://placehold.co/60x70/F3E8EA/243A73?text=N'">
            <div class="co-item-info">
                <span class="co-item-name">${item.name}</span>
                <span class="co-item-qty">× ${item.qty}</span>
            </div>
            <span class="co-item-price">PKR ${(item.price * item.qty).toLocaleString()}</span>
        </div>
    `).join('') || '<p class="empty-bag-note">No items in bag.</p>';

    if (coSubtotal) coSubtotal.textContent = `PKR ${subtotal.toLocaleString()}`;
    if (coTotal)    coTotal.textContent    = `PKR ${total.toLocaleString()}`;
}

function goToStep(num) {
    [1, 2, 3].forEach(n => {
        const step = document.getElementById(`form-step-${n}`);
        const ind  = document.getElementById(`step-indicator-${n}`);
        if (step) step.style.display = n === num ? 'block' : 'none';
        if (ind) {
            ind.classList.toggle('active', n === num);
            ind.classList.toggle('completed', n < num);
        }
    });
    const activeStep = document.getElementById(`form-step-${num}`);
    if (activeStep) gsap.from(activeStep, { opacity: 0, y: 20, duration: 0.4, ease: 'power2.out' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function validateDelivery() {
    const fields = ['first-name', 'last-name', 'phone', 'address', 'city'];
    let valid = true;
    fields.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        if (!el.value.trim()) { el.classList.add('input-error'); valid = false; }
        else                   el.classList.remove('input-error');
    });
    if (!valid) {
        const form = document.getElementById('delivery-form');
        gsap.from(form, { x: -8, duration: 0.4, repeat: 3, yoyo: true, ease: 'power1.inOut' });
    }
    return valid;
}

function buildReview() {
    const fname    = document.getElementById('first-name')?.value || '';
    const lname    = document.getElementById('last-name')?.value  || '';
    const phone    = document.getElementById('phone')?.value      || '';
    const address  = document.getElementById('address')?.value    || '';
    const city     = document.getElementById('city')?.value       || '';
    const payVal   = document.querySelector('input[name="payment"]:checked')?.value || 'cod';
    const payLabel = { cod: 'Cash on Delivery', bank: 'Bank Transfer', jazzcash: 'JazzCash / EasyPaisa' };

    const deliveryEl = document.getElementById('review-delivery');
    const paymentEl  = document.getElementById('review-payment');
    const itemsEl    = document.getElementById('review-items');
    const totalEl    = document.getElementById('review-total');

    if (deliveryEl) deliveryEl.innerHTML = `<p>${fname} ${lname}</p><p>${phone}</p><p>${address}, ${city}</p>`;
    if (paymentEl)  paymentEl.innerHTML  = `<p>${payLabel[payVal] || payVal}</p>`;
    if (itemsEl)    itemsEl.innerHTML    = cart.map(item =>
        `<div class="review-item-row"><span>${item.name} × ${item.qty}</span><span>PKR ${(item.price * item.qty).toLocaleString()}</span></div>`
    ).join('');
    if (totalEl) totalEl.textContent = `PKR ${(getSubtotal() + 200).toLocaleString()}`;
}

// ── Place Order via REST API ──────────────────────────────────
function placeOrder() {
    const btn = document.getElementById('place-order-btn');
    if (!btn) return;

    if (cart.length === 0) {
        showToast('<i class="fas fa-exclamation-circle"></i> Your bag is empty!');
        return;
    }

    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Placing Order...';
    btn.disabled  = true;

    const orderData = {
        first_name: document.getElementById('first-name')?.value || '',
        last_name:  document.getElementById('last-name')?.value  || '',
        phone:      document.getElementById('phone')?.value      || '',
        email:      document.getElementById('email')?.value      || '',
        address:    document.getElementById('address')?.value    || '',
        city:       document.getElementById('city')?.value       || '',
        postal:     document.getElementById('postal')?.value     || '',
        notes:      document.getElementById('notes')?.value      || '',
        payment:    document.querySelector('input[name="payment"]:checked')?.value || 'cod',
        items:      cart.map(i => ({
            id:    i.id,
            name:  i.name,
            price: i.price,
            qty:   i.qty,
            image: i.image || ''
        }))
    };

    fetch(ncRest + 'orders', {
        method:  'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce':   ncNonce
        },
        body: JSON.stringify(orderData)
    })
    .then(r => r.json())
    .then(res => {
        if (res.success) {
            // Clear cart
            cart = [];
            saveCart();
            updateCartBadge();

            // Show confirmation in page
            const layout    = document.getElementById('checkout-form-layout');
            const confirmed = document.getElementById('order-confirmed');
            const header    = document.querySelector('.checkout-header');
            const numEl     = document.getElementById('order-confirmed-number');

            if (layout)    layout.style.display    = 'none';
            if (header)    header.style.display    = 'none';
            if (numEl)     numEl.textContent        = 'Order #' + res.order_number;
            if (confirmed) {
                confirmed.style.display = 'flex';
                gsap.from(confirmed, { opacity: 0, scale: 0.9, duration: 0.6, ease: 'back.out(1.7)' });
            }
        } else {
            btn.innerHTML = '<i class="fas fa-check"></i> Place Order';
            btn.disabled  = false;
            showToast('<i class="fas fa-exclamation-circle"></i> ' + (res.message || 'Something went wrong. Please try again.'));
        }
    })
    .catch(err => {
        btn.innerHTML = '<i class="fas fa-check"></i> Place Order';
        btn.disabled  = false;
        showToast('<i class="fas fa-exclamation-circle"></i> Network error. Please try again.');
        console.error('Order error:', err);
    });
}
