<?php
/**
 * Template Name: page-new-arrivals.php
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="The latest handmade arrivals at Nabirosa Closet — fresh pieces added just for you.">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
    <style>
        .page-banner{background:linear-gradient(145deg,#ddd0f0 0%,var(--primary-lavender) 60%,#c5aee0 100%);padding:5rem 5% 4rem;text-align:center;position:relative;overflow:hidden}
        .page-banner::before{content:'';position:absolute;width:280px;height:280px;background:rgba(255,255,255,.2);border-radius:50%;bottom:-70px;right:-50px;pointer-events:none}
        .page-banner .banner-eyebrow{display:inline-block;font-size:.75rem;font-weight:600;letter-spacing:3px;text-transform:uppercase;color:var(--deep-royal-blue);background:rgba(255,255,255,.5);border:1px solid rgba(36,58,115,.2);padding:.35rem 1rem;border-radius:50px;margin-bottom:1rem;position:relative;z-index:2}
        .page-banner h1{font-size:3rem;color:var(--midnight-navy);margin-bottom:.5rem;position:relative;z-index:2}
        .page-banner p{color:var(--midnight-navy);opacity:.7;font-style:italic;position:relative;z-index:2}
        .banner-divider{width:40px;height:3px;background:linear-gradient(90deg,var(--champagne-gold),var(--deep-royal-blue));border-radius:3px;margin:.8rem auto 0;position:relative;z-index:2}
        .arrivals-section{padding:5rem 5%;background:var(--neutral-grey)}
        .shop-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;max-width:1200px;margin:0 auto}
        .shop-card{background:var(--neutral-white);border-radius:var(--radius-card);overflow:hidden;box-shadow:var(--shadow-md);transition:transform var(--transition),box-shadow var(--transition);display:flex;flex-direction:column}
        .shop-card:hover{transform:translateY(-8px);box-shadow:var(--shadow-lg)}
        .shop-card-img{position:relative;height:340px;background:var(--soft-rose-nude);overflow:hidden}
        .shop-card-img img{width:100%;height:100%;object-fit:cover;transition:transform .6s cubic-bezier(.4,0,.2,1)}
        .shop-card:hover .shop-card-img img{transform:scale(1.07)}
        .shop-card-badge{position:absolute;top:14px;left:14px;background:var(--champagne-gold);color:var(--midnight-navy);font-size:.7rem;font-weight:700;padding:.3rem .9rem;border-radius:50px;letter-spacing:1.5px;text-transform:uppercase}
        .shop-card-body{padding:1.5rem 1.6rem 1.8rem;flex:1;display:flex;flex-direction:column}
        .shop-card-body h3{font-size:1.15rem;color:var(--midnight-navy);margin-bottom:.5rem}
        .shop-card-prices{display:flex;align-items:center;gap:.7rem;margin-bottom:1.2rem;flex-wrap:wrap}
        .shop-card-prices .orig{text-decoration:line-through;color:#bbb;font-size:.9rem}
        .shop-card-prices .sale{color:var(--deep-royal-blue);font-weight:700;font-size:1.2rem}
        .shop-card-prices .pill{background:#FEF3C7;color:#92400E;font-size:.7rem;font-weight:600;padding:.15rem .6rem;border-radius:50px}
        .shop-add-btn{margin-top:auto;width:100%;padding:.85rem;background:var(--midnight-navy);color:#fff;border-radius:var(--radius-btn);font-size:.85rem;font-weight:600;letter-spacing:1px;text-transform:uppercase;transition:all var(--transition);display:flex;align-items:center;justify-content:center;gap:.5rem}
        .shop-add-btn:hover{background:var(--champagne-gold);color:var(--midnight-navy);transform:translateY(-2px)}
        @media(max-width:1024px){.shop-grid{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:480px){.shop-grid{grid-template-columns:repeat(2,1fr);gap:.8rem}.shop-card-img{height:180px}.page-banner h1{font-size:1.8rem}.shop-card-body{padding:.8rem}.shop-card-body h3{font-size:.85rem}.shop-card-prices .orig,.shop-card-prices .pill,.shop-add-btn{display:none}.shop-card-prices .sale{font-size:1rem}}
    </style>
</head>
<body>
<?php get_template_part('template-parts/navbar'); ?>

<div class="page-banner">
    <span class="banner-eyebrow">Just Dropped</span>
    <h1>New Arrivals</h1>
    <p>Fresh from the artisan's hands — just for you.</p>
    <div class="banner-divider"></div>
</div>

<section class="arrivals-section">
    <div class="shop-grid">
        <?php
        $products = NC_Products::get_all( true ); // new_arrivals_only = true
        if ( empty($products) ) {
            $products = NC_Products::get_all(); // fallback: show all
        }
        foreach ( $products as $product ) {
            get_template_part('template-parts/product-card', null, ['product' => $product]);
        }
        ?>
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
<?php get_template_part('template-parts/quick-view-modal'); ?>
</body>
</html>
