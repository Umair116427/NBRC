<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ── Theme Setup ───────────────────────────────────────────────
add_action( 'after_setup_theme', 'nabirosa_setup' );
function nabirosa_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}

// ── Enqueue Assets ────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', 'nabirosa_enqueue' );
function nabirosa_enqueue() {
    $theme_uri = get_template_directory_uri();
    $ver       = '1.0.0';

    // Google Fonts
    wp_enqueue_style( 'nc-fonts', 'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600&family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Pacifico&display=swap', [], null );

    // Font Awesome
    wp_enqueue_style( 'nc-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', [], '6.4.0' );

    // Main CSS
    wp_enqueue_style( 'nc-main', $theme_uri . '/assets/css/nabirosa.css', [], $ver );

    // GSAP
    wp_enqueue_script( 'nc-gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', [], '3.12.2', false );
    wp_enqueue_script( 'nc-gsap-st', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', [ 'nc-gsap' ], '3.12.2', false );

    // Main script
    wp_enqueue_script( 'nc-script', $theme_uri . '/assets/js/nabirosa.js', [ 'nc-gsap' ], $ver, true );

    // Pass data to JS
    wp_localize_script( 'nc-script', 'nc_data', [
        'rest_url'      => esc_url_raw( rest_url( 'nabirosa/v1/' ) ),
        'nonce'         => wp_create_nonce( 'wp_rest' ),
        'home_url'      => home_url( '/' ),
        'shop_url'      => home_url( '/shop/' ),
        'arrivals_url'  => home_url( '/new-arrivals/' ),
        'about_url'     => home_url( '/about/' ),
        'cart_url'      => home_url( '/cart/' ),
        'checkout_url'  => home_url( '/checkout/' ),
        'confirmed_url' => home_url( '/order-confirmed/' ),
    ] );
}

// ── Page URL helpers (for templates) ──────────────────────────
function nc_url( $page = 'home' ) {
    $map = [
        'home'      => home_url( '/' ),
        'shop'      => home_url( '/shop/' ),
        'arrivals'  => home_url( '/new-arrivals/' ),
        'about'     => home_url( '/about/' ),
        'cart'      => home_url( '/cart/' ),
        'checkout'  => home_url( '/checkout/' ),
        'confirmed' => home_url( '/order-confirmed/' ),
    ];
    return esc_url( $map[ $page ] ?? home_url( '/' ) );
}

// ── Active nav link helper ─────────────────────────────────────
function nc_active( $page ) {
    $current = $_SERVER['REQUEST_URI'] ?? '';
    $map = [
        'home'     => '/',
        'shop'     => '/shop',
        'arrivals' => '/new-arrivals',
        'about'    => '/about',
        'cart'     => '/cart',
        'checkout' => '/checkout',
    ];
    $path = $map[ $page ] ?? '';
    if ( $page === 'home' ) {
        return ( untrailingslashit($current) === '' || $current === '/' ) ? 'class="active"' : '';
    }
    return ( strpos( $current, $path ) !== false ) ? 'class="active"' : '';
}

function nc_bottom_active( $page ) {
    $current = $_SERVER['REQUEST_URI'] ?? '';
    $map = [
        'home'     => '/',
        'shop'     => '/shop',
        'arrivals' => '/new-arrivals',
        'about'    => '/about',
        'cart'     => '/cart',
    ];
    $path = $map[ $page ] ?? '';
    if ( $page === 'home' ) {
        return ( untrailingslashit($current) === '' || $current === '/' ) ? 'class="bottom-nav-item active"' : 'class="bottom-nav-item"';
    }
    return ( strpos( $current, $path ) !== false ) ? 'class="bottom-nav-item active"' : 'class="bottom-nav-item"';
}
