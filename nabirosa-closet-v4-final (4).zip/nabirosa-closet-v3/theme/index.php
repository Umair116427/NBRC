<?php
/**
 * Home page template (index.php)
 * Nabirosa Closet Theme
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Discover handcrafted fashion exclusively at Nabirosa Closet — where every stitch tells a story.">
    <link rel="icon" type="image/png" href="https://raw.githubusercontent.com/Umair116427/NBRC/main/logo%20nabi.png">
    <?php wp_head(); ?>
</head>
<body>

<!-- Loading Screen -->
<div class="loader">
    <div class="loader-text">
        <img src="https://raw.githubusercontent.com/Umair116427/NBRC/refs/heads/main/Pastel_Purple_Retro_Bold_Cafe_Logo-removebg-preview__2_-removebg-preview.png" alt="Nabirosa Closet Logo">
    </div>
    <div class="loader-bar"></div>
</div>

<?php get_template_part('template-parts/navbar'); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <span class="hero-eyebrow">Exclusively Handcrafted</span>
        <h1 class="hero-title">Handmade<br><em>Elegance</em></h1>
        <p class="hero-subtitle">Discover the unique charm of handcrafted fashion. Every piece is a work of art, made with love.</p>
        <div class="hero-actions">
            <a href="<?php echo nc_url('shop'); ?>" class="btn-primary hero-btn">
                <i class="fas fa-arrow-right"></i> Explore Collection
            </a>
            <a href="<?php echo nc_url('about'); ?>" class="btn-outline">Our Story</a>
        </div>
    </div>
    <div class="hero-scroll-cue">
        <i class="fas fa-chevron-down"></i>
        <span>Scroll</span>
    </div>
</section>

<!-- Featured Section -->
<section class="featured" id="featured">
    <div class="section-header">
        <h2>Featured Masterpiece</h2>
        <p>One of a kind, just for you.</p>
        <div class="section-divider"></div>
    </div>
    <div class="product-grid">
        <?php
        $products = NC_Products::get_all();
        foreach ( $products as $product ) :
            // Use featured card style for home page
            $discount = '';
            if ( $product->orig_price && $product->price < $product->orig_price ) {
                $discount = round( (1 - $product->price / $product->orig_price) * 100 ) . '% OFF';
            }
            $meta_tags = array_filter(explode(',', $product->meta_tags));
        ?>
        <div class="product-card quick-view-trigger"
             data-id="<?php echo esc_attr($product->id); ?>"
             data-name="<?php echo esc_attr($product->name); ?>"
             data-price="<?php echo esc_attr($product->price); ?>"
             data-orig="<?php echo esc_attr($product->orig_price ?? ''); ?>"
             data-discount="<?php echo esc_attr($discount); ?>"
             data-badge="<?php echo esc_attr($product->badge); ?>"
             data-desc="<?php echo esc_attr($product->description); ?>"
             data-image="<?php echo esc_attr($product->image_url); ?>"
             data-coming-soon="<?php echo $product->is_coming_soon ? '1' : '0'; ?>">
            <div class="product-image">
                <img src="<?php echo esc_url($product->image_url); ?>"
                     alt="<?php echo esc_attr($product->name); ?>"
                     onerror="this.src='https://placehold.co/600x800/F3E8EA/243A73?text=Nabirosa+Closet'">
                <?php if ($product->badge): ?>
                <div class="sale-badge" <?php if($product->is_coming_soon) echo 'style="background:var(--midnight-navy);"'; ?>>
                    <?php echo esc_html($product->badge); ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="product-info">
                <h3><?php echo esc_html($product->name); ?></h3>
                <div class="price-container">
                    <?php if ($product->orig_price): ?>
                    <span class="original-price">PKR <?php echo number_format($product->orig_price, 0); ?></span>
                    <?php endif; ?>
                    <?php if (!$product->is_coming_soon): ?>
                    <span class="sale-price">PKR <?php echo number_format($product->price, 0); ?></span>
                    <?php if ($discount): ?><span class="discount-pill"><?php echo esc_html($discount); ?></span><?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if ($meta_tags): ?>
                <div class="product-meta">
                    <?php foreach($meta_tags as $tag): ?>
                    <span><i class="fas fa-star"></i> <?php echo esc_html(trim($tag)); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <p class="product-desc"><?php echo esc_html($product->description); ?></p>
                <?php if ($product->is_coming_soon): ?>
                <button class="add-to-cart-btn" style="background:#ccc;color:#666;cursor:not-allowed;" disabled>
                    <i class="fas fa-lock"></i> Stay Tuned
                </button>
                <?php else: ?>
                <button class="add-to-cart-btn"
                        data-id="<?php echo esc_attr($product->id); ?>"
                        data-name="<?php echo esc_attr($product->name); ?>"
                        data-price="<?php echo esc_attr($product->price); ?>"
                        data-image="<?php echo esc_attr($product->image_url); ?>">
                    <i class="fas fa-shopping-bag"></i> Add to Bag
                </button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<?php get_template_part('template-parts/footer'); ?>
<?php get_template_part('template-parts/quick-view-modal'); ?>
</body>
</html>
