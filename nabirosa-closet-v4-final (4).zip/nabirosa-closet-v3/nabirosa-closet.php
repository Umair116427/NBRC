<?php
/**
 * Plugin Name: Nabirosa Closet
 * Plugin URI:  https://nabirosacloset.com
 * Description: Complete storefront + order management for Nabirosa Closet. Bundles the custom theme, activates it automatically, and provides a full analytics dashboard.
 * Version:     3.0.0
 * Author:      Umair Ali
 * Author URI:  https://github.com/Umair116427
 * Text Domain: nabirosa-closet
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'NC_VERSION',    '3.0.0' );
define( 'NC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'NC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'NC_THEME_SLUG', 'nabirosa-theme' );

require_once NC_PLUGIN_DIR . 'includes/class-database.php';
require_once NC_PLUGIN_DIR . 'includes/class-products.php';
require_once NC_PLUGIN_DIR . 'includes/class-orders.php';
require_once NC_PLUGIN_DIR . 'includes/class-analytics.php';
require_once NC_PLUGIN_DIR . 'includes/class-api.php';
require_once NC_PLUGIN_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, 'nc_activate' );
function nc_activate() {
    NC_Database::create_tables();
    NC_Products::seed_default_products();
    nc_install_theme();
    nc_create_pages();
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'nc_deactivate' );
function nc_deactivate() { flush_rewrite_rules(); }

function nc_install_theme() {
    $source      = NC_PLUGIN_DIR . 'theme/';
    $destination = get_theme_root() . '/' . NC_THEME_SLUG . '/';
    if ( ! is_dir( $destination ) ) nc_copy_directory( $source, $destination );
    if ( get_option( 'template' ) !== NC_THEME_SLUG ) switch_theme( NC_THEME_SLUG );
}

function nc_copy_directory( $src, $dst ) {
    if ( ! is_dir( $dst ) ) wp_mkdir_p( $dst );
    foreach ( scandir( $src ) as $item ) {
        if ( $item === '.' || $item === '..' ) continue;
        is_dir( $src.$item ) ? nc_copy_directory( $src.$item.'/', $dst.$item.'/' ) : copy( $src.$item, $dst.$item );
    }
}

function nc_create_pages() {
    $pages = [
        'shop'            => [ 'title' => 'Shop Collection',  'template' => 'page-shop.php' ],
        'new-arrivals'    => [ 'title' => 'New Arrivals',     'template' => 'page-new-arrivals.php' ],
        'about'           => [ 'title' => 'About Us',         'template' => 'page-about.php' ],
        'cart'            => [ 'title' => 'Your Bag',         'template' => 'page-cart.php' ],
        'checkout'        => [ 'title' => 'Checkout',         'template' => 'page-checkout.php' ],
        'order-confirmed' => [ 'title' => 'Order Confirmed',  'template' => 'page-order-confirmed.php' ],
    ];
    foreach ( $pages as $slug => $data ) {
        if ( ! get_page_by_path( $slug ) ) {
            $id = wp_insert_post( [ 'post_title' => $data['title'], 'post_name' => $slug, 'post_status' => 'publish', 'post_type' => 'page' ] );
            if ( $id && ! is_wp_error( $id ) ) update_post_meta( $id, '_wp_page_template', $data['template'] );
        }
    }
}

add_action( 'init',                  [ 'NC_API',   'register_routes' ] );
add_action( 'admin_menu',            [ 'NC_Admin', 'add_menu' ] );
add_action( 'admin_enqueue_scripts', [ 'NC_Admin', 'enqueue_scripts' ] );
add_action( 'wp_ajax_nc_update_order_status', [ 'NC_Admin', 'ajax_update_status' ] );
add_action( 'wp_ajax_nc_get_analytics',       [ 'NC_Admin', 'ajax_analytics' ] );
